import os
from config_db import get_supabase_client
from dotenv import load_dotenv

load_dotenv()

supabase = get_supabase_client()

try:
    # Try to insert a dummy record to see what columns are accepted, 
    # or just fetch one row and see keys if any exist.
    # Better: Query the information_schema via SQL if possible, but we can't easily via client.
    # We'll try to fetch one row.
    res = supabase.table("trend_eye_insights").select("*").limit(1).execute()
    print("Successfully fetched from trend_eye_insights.")
    if res.data:
        print(f"Columns found: {list(res.data[0].keys())}")
    else:
        print("Table is empty, cannot infer columns from data.")
        
    # Attempt to insert a dummy record with period_type to see if it fails
    print("Attempting dummy insert with period_type...")
    dummy = {
        "period": "TEST-001",
        "period_type": "test",
        "trend_summary": "test"
    }
    supabase.table("trend_eye_insights").insert(dummy).execute()
    print("Dummy insert successful.")
    
    # Clean up
    supabase.table("trend_eye_insights").delete().eq("period", "TEST-001").execute()

except Exception as e:
    print(f"Error: {e}")
