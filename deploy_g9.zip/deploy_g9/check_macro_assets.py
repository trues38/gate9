from config_db import get_supabase_client
import pandas as pd

def check_macro_assets():
    supabase = get_supabase_client()
    print("🕵️‍♂️ Checking for Macro Assets (Dollar, Gold, Oil, Yield)...")

    # Potential Tickers to look for
    target_tickers = [
        "DX-Y.NYB", "DXY", # Dollar
        "GC=F", "GOLD", # Gold
        "CL=F", "OIL", # Oil
        "^TNX", "US10Y" # Treasury Yield
    ]

    # 1. Check ingest_prices
    print("\n📉 Checking 'ingest_prices' table...")
    try:
        # Get all distinct tickers first
        res = supabase.table("ingest_prices").select("ticker").execute()
        existing_tickers = set(row['ticker'] for row in res.data)
        
        found_tickers = [t for t in existing_tickers if any(x in t for x in target_tickers) or t in target_tickers]
        
        if not found_tickers:
            print("   ❌ No obvious macro asset tickers found in ingest_prices.")
            print(f"   ℹ️ Existing Tickers: {list(existing_tickers)[:10]}...")
        else:
            for t in found_tickers:
                # Check date range
                res_min = supabase.table("ingest_prices").select("date").eq("ticker", t).order("date", desc=False).limit(1).execute()
                res_max = supabase.table("ingest_prices").select("date").eq("ticker", t).order("date", desc=True).limit(1).execute()
                
                start_date = res_min.data[0]['date'] if res_min.data else "N/A"
                end_date = res_max.data[0]['date'] if res_max.data else "N/A"
                
                print(f"   ✅ Found {t}: {start_date} ~ {end_date}")

    except Exception as e:
        print(f"   ⚠️ Error checking ingest_prices: {e}")

    # 2. Check indicators (if exists)
    print("\n📊 Checking 'indicators' table...")
    try:
        # Check if table exists by trying to select
        res = supabase.table("indicators").select("*").limit(1).execute()
        if not res.data:
             print("   ℹ️ Table 'indicators' is empty or not accessible.")
        else:
             # Check columns to see how to identify assets
             print(f"   ℹ️ Columns: {list(res.data[0].keys())}")
             # Assuming 'name' or 'ticker' column
             # Let's try to list distinct names if possible, or just dump a few
             res_all = supabase.table("indicators").select("name").execute() # Warning: might be large
             names = set(row.get('name') for row in res_all.data)
             print(f"   ℹ️ Indicator Names: {names}")
             
    except Exception as e:
        print(f"   ⚠️ Error checking indicators (Table might not exist): {e}")

if __name__ == "__main__":
    check_macro_assets()
