import argparse
from backtest_engine import BacktestEngine

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start_year", type=int, default=2000)
    parser.add_argument("--end_year", type=int, default=2025)
    parser.add_argument("--ticker", type=str, default="SPY")
    parser.add_argument("--country", type=str, default="US")
    args = parser.parse_args()
    
    start_date = f"{args.start_year}-01-01"
    end_date = f"{args.end_year}-12-31"
    
    print(f"🚀 Starting Backtest Launcher ({start_date} ~ {end_date}) for {args.ticker} ({args.country}) using GLOBAL signals")
    
    engine = BacktestEngine(market_ticker=args.ticker, market_country=args.country, macro_country="GLOBAL")
    
    # Define Primitive Strategies
    strategies = [
        # 1. Z-Score Primitives
        {
            "id": "PRIM_Z_SCORE_1.0",
            "type": "Z_SCORE",
            "params": {"threshold": 1.0, "filter_noise": True}
        },
        {
            "id": "PRIM_Z_SCORE_1.5",
            "type": "Z_SCORE",
            "params": {"threshold": 1.5, "filter_noise": True}
        },
        {
            "id": "PRIM_Z_SCORE_2.0",
            "type": "Z_SCORE",
            "params": {"threshold": 2.0, "filter_noise": True}
        },
        
        # 2. Delta-Z Primitives
        {
            "id": "PRIM_DELTA_Z_1.0",
            "type": "DELTA_Z",
            "params": {"threshold": 1.0, "filter_noise": True}
        },
        {
            "id": "PRIM_DELTA_Z_1.5",
            "type": "DELTA_Z",
            "params": {"threshold": 1.5, "filter_noise": True}
        },
        {
            "id": "PRIM_DELTA_Z_2.0",
            "type": "DELTA_Z",
            "params": {"threshold": 2.0, "filter_noise": True}
        }
    ]
    
    print(f"📋 Loaded {len(strategies)} strategies.")
    
    for i, strategy in enumerate(strategies):
        print(f"\n[{i+1}/{len(strategies)}] Running {strategy['id']}...")
        engine.run_backtest(start_date, end_date, strategy)
        
    print("\n🎉 All Backtests Complete!")

if __name__ == "__main__":
    main()
