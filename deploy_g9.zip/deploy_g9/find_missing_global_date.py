import os
from config_db import get_supabase_client

def find_missing():
    print("🔍 Finding missing GLOBAL dates...")
    supabase = get_supabase_client()
    
    # Helper to fetch all dates
    def fetch_all_dates(country):
        dates = set()
        start = 0
        batch_size = 1000
        while True:
            res = supabase.table("preprocess_daily")\
                .select("date")\
                .eq("country", country)\
                .range(start, start + batch_size - 1)\
                .execute()
            if not res.data:
                break
            for row in res.data:
                dates.add(row['date'])
            start += batch_size
            if len(res.data) < batch_size:
                break
        return dates

    # 1. Fetch all dates for US (Reference)
    print("   Fetching US dates (this may take a moment)...")
    us_dates = fetch_all_dates("US")
    print(f"   🇺🇸 US Dates: {len(us_dates)}")
    
    # 2. Fetch all dates for GLOBAL
    print("   Fetching GLOBAL dates...")
    global_dates = fetch_all_dates("GLOBAL")
    print(f"   🌍 GLOBAL Dates: {len(global_dates)}")
    
    # 3. Find Difference
    missing = us_dates - global_dates
    
    if not missing:
        print("✅ No missing dates found! (Counts match or GLOBAL has extras)")
    else:
        print(f"❌ Missing {len(missing)} dates in GLOBAL:")
        for d in sorted(missing):
            print(f"   - {d}")
            
    # Optional: Check for extras in GLOBAL
    extras = global_dates - us_dates
    if extras:
        print(f"⚠️ GLOBAL has {len(extras)} extra dates not in US:")
        for d in sorted(extras):
            print(f"   + {d}")

if __name__ == "__main__":
    find_missing()
