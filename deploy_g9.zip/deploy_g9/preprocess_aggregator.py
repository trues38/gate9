import pandas as pd
from datetime import datetime, timedelta
from config_db import get_supabase_client

class Aggregator:
    def __init__(self):
        self.supabase = get_supabase_client()

    def run_all(self, start_year=2000, end_year=2025, countries=None):
        if countries is None:
            countries = ["US", "KR", "JP", "CN", "GLOBAL"]
            
        for country in countries:
            print(f"🚀 Aggregating for {country} ({start_year}-{end_year})...")
            self.aggregate_period(start_year, end_year, country, "weekly")
            self.aggregate_period(start_year, end_year, country, "monthly")
            self.aggregate_period(start_year, end_year, country, "annual")

    def aggregate_period(self, start_year, end_year, country, period_type):
        # Fetch all daily data for the range
        start_date = f"{start_year}-01-01"
        end_date = f"{end_year}-12-31"
        
        print(f"   Fetching daily data for {period_type} aggregation...")
        
        all_data = self._fetch_all_daily(country, start_date, end_date)
        if not all_data:
            print(f"   ⚠️ No data found for {country}")
            return

        df = pd.DataFrame(all_data)
        df['date'] = pd.to_datetime(df['date'])
        
        # Resample
        if period_type == "weekly":
            # W-MON: Weekly starting Monday
            resampled = df.resample('W-MON', on='date')
            target_table = "preprocess_weekly"
        elif period_type == "monthly":
            resampled = df.resample('MS', on='date') # Month Start
            target_table = "preprocess_monthly"
        elif period_type == "annual":
            resampled = df.resample('AS', on='date') # Year Start
            target_table = "preprocess_annual"
            
        # Aggregation rules
        # Ensure columns exist before aggregating
        agg_rules = {}
        if 'zscore' in df.columns: agg_rules['zscore'] = 'mean'
        if 'delta_z' in df.columns: agg_rules['delta_z'] = 'mean'
        if 'noise_rate' in df.columns: agg_rules['noise_rate'] = 'mean'
        if 'headline_count' in df.columns: agg_rules['headline_count'] = 'sum'
        if 'valid_headline_count' in df.columns: agg_rules['valid_headline_count'] = 'sum'
        
        if not agg_rules:
            print("   ⚠️ No valid columns to aggregate.")
            return
        
        agg_df = resampled.agg(agg_rules)
        
        # Reset index to get date column back
        agg_df = agg_df.reset_index()
        
        # Prepare payload
        records = []
        for _, row in agg_df.iterrows():
            if pd.isna(row.get('zscore')): continue # Skip empty periods
            
            record = {
                "date": row['date'].strftime("%Y-%m-%d"),
                "country": country,
                "created_at": "now()"
            }
            
            # Add fields if they exist
            if 'zscore' in row: record['zscore'] = row['zscore']
            if 'delta_z' in row: record['delta_z'] = row['delta_z']
            if 'noise_rate' in row: record['noise_rate'] = row['noise_rate']
            if 'headline_count' in row: record['headline_count'] = int(row['headline_count'])
            if 'valid_headline_count' in row: record['valid_headline_count'] = int(row['valid_headline_count'])
            
            records.append(record)
            
        # Batch Upsert
        if records:
            self._batch_upsert(target_table, records)
            print(f"   ✅ {period_type.capitalize()}: Saved {len(records)} rows.")

    def _fetch_all_daily(self, country, start_date, end_date):
        all_rows = []
        start = 0
        batch_size = 1000
        while True:
            res = self.supabase.table("preprocess_daily")\
                .select("*")\
                .eq("country", country)\
                .gte("date", start_date)\
                .lte("date", end_date)\
                .range(start, start + batch_size - 1)\
                .execute()
            
            if not res.data:
                break
            all_rows.extend(res.data)
            if len(res.data) < batch_size:
                break
            start += batch_size
        return all_rows

    def _batch_upsert(self, table, records):
        batch_size = 100
        for i in range(0, len(records), batch_size):
            batch = records[i:i+batch_size]
            try:
                self.supabase.table(table).upsert(batch, on_conflict="date, country").execute()
            except Exception as e:
                print(f"   ❌ Error saving to {table}: {e}")

if __name__ == "__main__":
    agg = Aggregator()
    agg.run_all()
