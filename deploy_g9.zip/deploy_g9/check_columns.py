from config_db import get_supabase_client

def check_columns():
    print("🔍 Checking columns for 'preprocess_weekly'...")
    supabase = get_supabase_client()
    
    try:
        # Try to fetch one row to see keys
        res = supabase.table("preprocess_weekly").select("*").limit(1).execute()
        if res.data:
            print(f"   ✅ Columns found: {list(res.data[0].keys())}")
        else:
            print("   ⚠️ Table is empty, cannot infer columns from data.")
            # Try inserting a dummy to see error or success? No, risky.
            # Just report empty.
            
    except Exception as e:
        print(f"   ❌ Error fetching: {e}")

if __name__ == "__main__":
    check_columns()
