-- G9 Macro Engine - Trading Simulation Schema
-- Run this in Supabase SQL Editor

-- 1. Backtest Trades (Execution Log)
CREATE TABLE IF NOT EXISTS backtest_trades (
    id BIGSERIAL PRIMARY KEY,
    trade_date DATE NOT NULL,
    ticker TEXT NOT NULL,
    strategy_id TEXT NOT NULL, -- The strategy used (e.g. "ZSCORE_2_BREAKOUT")
    signal_type TEXT NOT NULL, -- LONG / SHORT
    raw_signal_value FLOAT,
    decision TEXT NOT NULL,    -- LONG / SHORT / HOLD / NONE
    entry_price FLOAT,
    exit_price FLOAT,
    return_1d FLOAT,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Backtest Portfolio (NAV Curve)
CREATE TABLE IF NOT EXISTS backtest_portfolio (
    id BIGSERIAL PRIMARY KEY,
    date DATE NOT NULL,
    ticker TEXT NOT NULL,      -- Portfolio for which asset?
    strategy_id TEXT NOT NULL, -- Portfolio for which strategy?
    nav FLOAT NOT NULL,        -- Net Asset Value (starts at 1.0)
    daily_return FLOAT,
    drawdown FLOAT,
    position_size FLOAT,       -- Allocation %
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(date, ticker, strategy_id)
);

-- Enable RLS
ALTER TABLE backtest_trades ENABLE ROW LEVEL SECURITY;
ALTER TABLE backtest_portfolio ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Enable all access for service role" ON backtest_trades FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON backtest_portfolio FOR ALL USING (true) WITH CHECK (true);
