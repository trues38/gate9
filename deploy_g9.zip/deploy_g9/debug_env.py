import os
from dotenv import load_dotenv

print(f"Current CWD: {os.getcwd()}")
print(f"Files in CWD: {os.listdir('.')}")

loaded = load_dotenv()
print(f"load_dotenv() returned: {loaded}")

# Manually parse .env to see keys
with open(".env", "r") as f:
    for line in f:
        if "=" in line:
            key = line.split("=")[0].strip()
            print(f"Found key in file: {key}")
