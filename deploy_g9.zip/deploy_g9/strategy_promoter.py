import json
from config_db import get_supabase_client
from datetime import datetime

class StrategyPromoter:
    def __init__(self):
        self.supabase = get_supabase_client()

    def promote_strategies(self):
        print("🚀 Promoting Strategies...")
        
        # Define the strategies to promote (Hardcoded based on User Request)
        strategies_to_promote = [
            {
                "strategy_id": "ZSCORE_2_BREAKOUT",
                "strategy_name": "Z-Score 2.0 Breakout Strategy",
                "based_on_pattern_id": "PRIM_Z_SCORE_2.0", # Must match pattern_id in backtest_patterns
                "entry_rule": {
                    "condition": "abs(zscore) >= 2.0",
                    "filters": {"noise_rate": "<= 0.3", "headline_count": ">= 10"}
                },
                "exit_rule": {"type": "forward_return", "horizon": "1D_or_5D"},
                "risk_rule": {"stop_loss": "adaptive"},
                "position_rule": {"size": "dynamic"},
                "win_rate": 0.5791,
                "avg_return": 0.00099,
                "max_drawdown": -0.2379,
                "volatility": 0.0, # Placeholder
                "validation_score": 0.85, # Estimated score
                "is_active": True
            },
            {
                "strategy_id": "DELTAZ_2_REVERSAL",
                "strategy_name": "DeltaZ 2.0 Reversal Strategy",
                "based_on_pattern_id": "PRIM_DELTA_Z_2.0",
                "entry_rule": {
                    "condition": "abs(delta_z) >= 2.0",
                    "filters": {"noise_rate": "<= 0.2"}
                },
                "exit_rule": {"type": "forward_return", "horizon": "1D_or_5D"},
                "risk_rule": {"stop_loss": "adaptive"},
                "position_rule": {"size": "dynamic"},
                "win_rate": 0.5405,
                "avg_return": 0.00115,
                "max_drawdown": -0.4448,
                "volatility": 0.0, # Placeholder
                "validation_score": 0.80, # Estimated score
                "is_active": True
            }
        ]

        for st in strategies_to_promote:
            self._upsert_strategy(st)

    def _upsert_strategy(self, st_data):
        try:
            # Prepare payload
            payload = {
                "strategy_id": st_data["strategy_id"],
                "strategy_name": st_data["strategy_name"],
                "based_on_pattern_id": st_data["based_on_pattern_id"],
                "entry_rule": json.dumps(st_data["entry_rule"]),
                "exit_rule": json.dumps(st_data["exit_rule"]),
                "risk_rule": json.dumps(st_data["risk_rule"]),
                "position_rule": json.dumps(st_data["position_rule"]),
                "win_rate": st_data["win_rate"],
                "avg_return": st_data["avg_return"],
                "max_drawdown": st_data["max_drawdown"],
                "volatility": st_data["volatility"],
                "validation_score": st_data["validation_score"],
                "created_at": datetime.utcnow().isoformat()
            }
            
            # Upsert
            self.supabase.table("backtest_strategies").upsert(payload).execute()
            print(f"   ✅ Promoted: {st_data['strategy_name']} ({st_data['strategy_id']})")
            
        except Exception as e:
            print(f"   ❌ Error promoting {st_data['strategy_id']}: {e}")

if __name__ == "__main__":
    promoter = StrategyPromoter()
    promoter.promote_strategies()
