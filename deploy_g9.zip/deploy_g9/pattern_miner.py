import pandas as pd
import json
from config_db import get_supabase_client
from datetime import datetime

class PatternMiner:
    def __init__(self):
        self.supabase = get_supabase_client()

    def run_mining(self):
        print("⛏️ Starting Pattern Mining...")
        
        # 1. Fetch All Backtest Results
        # (For production, we might want to filter by date or incremental update)
        results = self._fetch_all_results()
        if not results:
            print("   ⚠️ No backtest results found to mine.")
            return

        df = pd.DataFrame(results)
        print(f"   📊 Loaded {len(df)} signals.")

        # 2. Group by Strategy (Pattern)
        # In V3, strategy_id in results maps to pattern_key
        patterns = []
        
        grouped = df.groupby('strategy_id')
        
        for strategy_id, group in grouped:
            stats = self._calculate_stats(group)
            
            # Extract metadata from the first row as conditions
            # (Assuming same strategy_id has same conditions)
            first_meta = group.iloc[0]['metadata']
            conditions = json.loads(first_meta) if isinstance(first_meta, str) else first_meta
            
            pattern_entry = {
                "pattern_id": strategy_id, # Using strategy_id as pattern_id for now (e.g. PRIM_Z_SCORE_1.0)
                "pattern_name": f"Pattern: {strategy_id}",
                "description": f"Automatically mined pattern for {strategy_id}",
                "conditions": conditions,
                "sample_count": stats['sample_count'],
                "win_rate": stats['win_rate'],
                "avg_return": stats['avg_return'],
                "max_drawdown": stats['max_drawdown'],
                "volatility": stats['volatility'],
                "source_signals": json.dumps({"count": len(group)}), # Simplified for now
                "created_at": datetime.utcnow().isoformat()
            }
            patterns.append(pattern_entry)

        # 3. Save to DB
        if patterns:
            self._save_patterns(patterns)
            print(f"   ✅ Mined and saved {len(patterns)} patterns.")
        else:
            print("   ℹ️ No patterns generated.")

    def _fetch_all_results(self):
        all_data = []
        offset = 0
        limit = 1000
        
        while True:
            try:
                res = self.supabase.table("backtest_results")\
                    .select("*")\
                    .range(offset, offset + limit - 1)\
                    .execute()
                
                if not res.data:
                    break
                    
                all_data.extend(res.data)
                
                if len(res.data) < limit:
                    break
                    
                offset += limit
            except Exception as e:
                print(f"   ❌ Error fetching results (offset {offset}): {e}")
                break
                
        return all_data

    def _calculate_stats(self, df):
        # Win Rate (1D Return > 0)
        wins = df[df['fwd_return_1d'] > 0]
        win_rate = len(wins) / len(df) if len(df) > 0 else 0.0
        
        # Avg Return (1D)
        avg_ret = df['fwd_return_1d'].mean()
        
        # Volatility (Std Dev of 1D returns)
        volatility = df['fwd_return_1d'].std()
        
        # Max Drawdown (Simple approximation based on cumulative return)
        # Sort by date first
        df_sorted = df.sort_values('date')
        # We need a continuous equity curve to calc MDD properly, 
        # but for discrete signals, we can sum returns.
        # This is an approximation for signal quality.
        cum_ret = (1 + df_sorted['fwd_return_1d'].fillna(0)).cumprod()
        peak = cum_ret.cummax()
        drawdown = (cum_ret - peak) / peak
        max_dd = drawdown.min()
        
        return {
            "sample_count": len(df),
            "win_rate": float(win_rate),
            "avg_return": float(avg_ret) if pd.notnull(avg_ret) else 0.0,
            "volatility": float(volatility) if pd.notnull(volatility) else 0.0,
            "max_drawdown": float(max_dd) if pd.notnull(max_dd) else 0.0
        }

    def _save_patterns(self, patterns):
        try:
            self.supabase.table("backtest_patterns").upsert(patterns).execute()
        except Exception as e:
            print(f"   ❌ Error saving patterns: {e}")

if __name__ == "__main__":
    miner = PatternMiner()
    miner.run_mining()
