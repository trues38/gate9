from config_db import get_supabase_client
from collections import defaultdict

def check_daily_counts():
    supabase = get_supabase_client()
    print("📊 Checking 'preprocess_daily' row counts per year...")
    
    # Fetch all dates (lightweight)
    all_dates = []
    start = 0
    batch_size = 5000
    while True:
        try:
            res = supabase.table("preprocess_daily").select("date, country").range(start, start + batch_size - 1).execute()
            if not res.data: break
            all_dates.extend(res.data)
            if len(res.data) < batch_size: break
            start += batch_size
        except Exception as e:
            print(f"❌ Error: {e}")
            break
            
    # Aggregate
    counts = defaultdict(lambda: defaultdict(int))
    for row in all_dates:
        year = row['date'][:4]
        country = row['country']
        counts[year][country] += 1
        
    # Print
    years = sorted(counts.keys())
    print(f"{'Year':<6} | {'US':<5} | {'KR':<5} | {'JP':<5} | {'CN':<5} | {'GLOBAL':<6}")
    print("-" * 50)
    for y in years:
        us = counts[y]['US']
        kr = counts[y]['KR']
        jp = counts[y]['JP']
        cn = counts[y]['CN']
        gl = counts[y]['GLOBAL']
        print(f"{y:<6} | {us:<5} | {kr:<5} | {jp:<5} | {cn:<5} | {gl:<6}")

if __name__ == "__main__":
    check_daily_counts()
