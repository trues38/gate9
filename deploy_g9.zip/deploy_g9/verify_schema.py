from config_db import get_supabase_client

def verify_schema():
    supabase = get_supabase_client()
    print("🔍 Verifying 'ingest_prices' schema...")
    
    try:
        # Try to select the 'country' column
        res = supabase.table("ingest_prices").select("country").limit(1).execute()
        print("   ✅ 'country' column exists and is accessible.")
    except Exception as e:
        print(f"   ❌ Error accessing 'country' column: {e}")
        print("   👉 Please run 'add_country_to_prices.sql' and RELOAD SCHEMA CACHE in Supabase.")

if __name__ == "__main__":
    verify_schema()
