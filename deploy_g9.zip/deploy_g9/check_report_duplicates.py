from config_db import get_supabase_client
from collections import defaultdict

def check_duplicates():
    supabase = get_supabase_client()
    print("📊 Checking for duplicates in 'preprocess_annual'...")
    
    try:
        res = supabase.table("preprocess_annual").select("year, country").execute()
        counts = defaultdict(int)
        for row in res.data:
            key = f"{row['year']}-{row['country']}"
            counts[key] += 1
            
        duplicates = {k: v for k, v in counts.items() if v > 1}
        
        if duplicates:
            print(f"   ❌ Found {len(duplicates)} duplicate groups!")
            for k, v in list(duplicates.items())[:5]:
                print(f"      {k}: {v} copies")
        else:
            print("   ✅ No duplicates found in 'preprocess_annual'.")
            
    except Exception as e:
        print(f"   ❌ Error: {e}")

if __name__ == "__main__":
    check_duplicates()
