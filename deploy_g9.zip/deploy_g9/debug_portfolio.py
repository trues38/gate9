from config_db import get_supabase_client
import pandas as pd

def debug_portfolio():
    supabase = get_supabase_client()
    print("🕵️‍♂️ Debugging backtest_portfolio...")

    try:
        # Fetch first 10 rows without filters
        res = supabase.table("backtest_portfolio").select("*").limit(10).execute()
        data = res.data
        
        if not data:
            print("   ❌ Table 'backtest_portfolio' is EMPTY.")
        else:
            print(f"   ✅ Found {len(data)} rows. Sample:")
            print(pd.DataFrame(data).head())
            
            # Check unique tickers
            res_tickers = supabase.table("backtest_portfolio").select("ticker").execute()
            tickers = set(row['ticker'] for row in res_tickers.data)
            print(f"   🏷️ Unique Tickers in DB: {tickers}")

    except Exception as e:
        print(f"   ⚠️ Error fetching data: {e}")

if __name__ == "__main__":
    debug_portfolio()
