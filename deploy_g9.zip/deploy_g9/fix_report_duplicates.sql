-- Fix Duplicates in Report Tables
-- Run this in Supabase SQL Editor

-- 1. Clean Annual Duplicates
DELETE FROM preprocess_annual a USING (
    SELECT min(ctid) as ctid, year, country
    FROM preprocess_annual 
    GROUP BY year, country HAVING count(*) > 1
) b
WHERE a.year = b.year 
AND a.country = b.country 
AND a.ctid <> b.ctid;

-- 2. Clean Monthly Duplicates
DELETE FROM preprocess_monthly a USING (
    SELECT min(ctid) as ctid, year, month, country
    FROM preprocess_monthly 
    GROUP BY year, month, country HAVING count(*) > 1
) b
WHERE a.year = b.year 
AND a.month = b.month 
AND a.country = b.country 
AND a.ctid <> b.ctid;

-- 3. Clean Weekly Duplicates
DELETE FROM preprocess_weekly a USING (
    SELECT min(ctid) as ctid, start_date, end_date, country
    FROM preprocess_weekly 
    GROUP BY start_date, end_date, country HAVING count(*) > 1
) b
WHERE a.start_date = b.start_date 
AND a.end_date = b.end_date 
AND a.country = b.country 
AND a.ctid <> b.ctid;

-- 4. Enforce Constraints (If missing)
ALTER TABLE preprocess_annual ADD CONSTRAINT preprocess_annual_unique UNIQUE (year, country);
ALTER TABLE preprocess_monthly ADD CONSTRAINT preprocess_monthly_unique UNIQUE (year, month, country);
ALTER TABLE preprocess_weekly ADD CONSTRAINT preprocess_weekly_unique UNIQUE (start_date, end_date, country);
