from config_db import get_supabase_client
import pandas as pd

def check_data_quality():
    supabase = get_supabase_client()
    print("🕵️‍♂️ Checking Data Quality...")

    # 1. Check Prices for ^KS11 (Recent Data)
    print("\n📉 Checking ingest_prices for ^KS11 (2021-01-01 onwards)...")
    try:
        res = supabase.table("ingest_prices")\
            .select("date, open, close")\
            .eq("ticker", "^KS11")\
            .gte("date", "2021-01-01")\
            .order("date")\
            .limit(10)\
            .execute()
        
        if res.data:
            df = pd.DataFrame(res.data)
            print(df.to_string(index=False))
        else:
            print("   ❌ No price data found for ^KS11 in 2021")
    except Exception as e:
        print(f"   ⚠️ Error fetching prices: {e}")

    # 2. Check Macro for GLOBAL (Recent Data)
    print("\n🌍 Checking preprocess_daily for GLOBAL (2021-01-01 onwards)...")
    try:
        res = supabase.table("preprocess_daily")\
            .select("date, zscore, delta_z")\
            .eq("country", "GLOBAL")\
            .gte("date", "2021-01-01")\
            .order("date")\
            .limit(10)\
            .execute()
            
        if res.data:
            df = pd.DataFrame(res.data)
            print(df.to_string(index=False))
        else:
            print("   ❌ No macro data found for GLOBAL in 2021")
    except Exception as e:
        print(f"   ⚠️ Error fetching macro: {e}")

if __name__ == "__main__":
    check_data_quality()
