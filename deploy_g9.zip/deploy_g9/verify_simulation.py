import pandas as pd
from config_db import get_supabase_client

def verify_simulation():
    supabase = get_supabase_client()
    print("📊 Verifying Simulation Results...")
    
    # Fetch all portfolio data
    # We just need the last row for each ticker to get Final NAV, 
    # and maybe aggregation for MDD.
    # Actually, let's fetch all and process in Pandas for accuracy.
    
    # Since fetching ALL might be heavy, let's fetch by ticker if we knew them.
    # Or just fetch distinct tickers first.
    
    tickers = ["SPY", "^KS11", "^N225", "000001.SS"]
    
    summary = []
    
    for ticker in tickers:
        print(f"   🔎 Checking {ticker}...")
        
        # Fetch data
        # Use the same robust fetcher logic or just simple fetch if data is not too huge?
        # Portfolio data for 25 years is ~6000 rows. Simple fetch might timeout if we fetch all columns.
        # Let's fetch just date, nav, drawdown.
        
        try:
            res = supabase.table("backtest_portfolio")\
                .select("date, nav, drawdown")\
                .eq("ticker", ticker)\
                .order("date", desc=False)\
                .execute()
            
            data = res.data
            if not data:
                print(f"      ⚠️ No data found for {ticker}")
                continue
                
            df = pd.DataFrame(data)
            
            start_date = df.iloc[0]['date']
            end_date = df.iloc[-1]['date']
            start_nav = df.iloc[0]['nav']
            final_nav = df.iloc[-1]['nav']
            max_dd = df['drawdown'].min() # Drawdown is usually negative
            
            # CAGR
            days = (pd.to_datetime(end_date) - pd.to_datetime(start_date)).days
            years = days / 365.25
            cagr = (final_nav / start_nav) ** (1/years) - 1 if years > 0 else 0.0
            
            summary.append({
                "Market": ticker,
                "Start": start_date,
                "End": end_date,
                "Final NAV": final_nav,
                "Return": (final_nav - start_nav) / start_nav,
                "CAGR": cagr,
                "MDD": max_dd
            })
            
        except Exception as e:
            print(f"      ❌ Error checking {ticker}: {e}")

    if summary:
        print("\n🏆 Simulation Summary 🏆")
        df_sum = pd.DataFrame(summary)
        # Format columns
        df_sum['Final NAV'] = df_sum['Final NAV'].map('{:.4f}'.format)
        df_sum['Return'] = df_sum['Return'].map('{:.2%}'.format)
        df_sum['CAGR'] = df_sum['CAGR'].map('{:.2%}'.format)
        df_sum['MDD'] = df_sum['MDD'].map('{:.2%}'.format)
        
        print(df_sum.to_string(index=False))
    else:
        print("\n   ℹ️ No results found yet.")

if __name__ == "__main__":
    verify_simulation()
