-- Fix missing columns in trend_eye_insights

ALTER TABLE trend_eye_insights 
ADD COLUMN IF NOT EXISTS period_type text;

ALTER TABLE trend_eye_insights 
ADD COLUMN IF NOT EXISTS raw_data_reference jsonb;

ALTER TABLE trend_eye_insights 
ADD COLUMN IF NOT EXISTS evaluation_placeholder jsonb DEFAULT '{}'::jsonb;

-- Reload Schema Cache to ensure PostgREST sees the new columns
NOTIFY pgrst, 'reload config';
