-- Fix Backtest Schema
-- Run this in Supabase SQL Editor

-- Add potentially missing columns
ALTER TABLE backtest_results ADD COLUMN IF NOT EXISTS fwd_return_1d FLOAT;
ALTER TABLE backtest_results ADD COLUMN IF NOT EXISTS fwd_return_5d FLOAT;
ALTER TABLE backtest_results ADD COLUMN IF NOT EXISTS fwd_return_20d FLOAT;

-- Reload Schema Cache is required after this!
