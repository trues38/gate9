import argparse
from datetime import datetime, timedelta
from trend_eye_engine import TrendEyeEngine
from future_eye_engine import FutureEyeEngine
from meta_rag_engine import MetaRAGEngine

def get_weeks(start_year, end_year):
    weeks = []
    start_date = datetime(start_year, 1, 1)
    end_date = datetime(end_year, 12, 31)
    
    # Adjust to Monday
    current = start_date - timedelta(days=start_date.weekday())
    
    while current < end_date:
        week_end = current + timedelta(days=6)
        label = f"{current.year}-W{current.isocalendar()[1]:02d}"
        weeks.append((label, "weekly", current.strftime("%Y-%m-%d"), week_end.strftime("%Y-%m-%d")))
        current += timedelta(days=7)
    return weeks

def get_months(start_year, end_year):
    months = []
    for year in range(start_year, end_year + 1):
        for month in range(1, 13):
            start = datetime(year, month, 1)
            if month == 12:
                end = datetime(year + 1, 1, 1) - timedelta(days=1)
            else:
                end = datetime(year, month + 1, 1) - timedelta(days=1)
            label = f"{year}-{month:02d}"
            months.append((label, "monthly", start.strftime("%Y-%m-%d"), end.strftime("%Y-%m-%d")))
    return months

def get_years(start_year, end_year):
    years = []
    for year in range(start_year, end_year + 1):
        label = str(year)
        start = f"{year}-01-01"
        end = f"{year}-12-31"
        years.append((label, "annual", start, end))
    return years

def main():
    parser = argparse.ArgumentParser(description="TrendyBot Launcher")
    parser.add_argument("--action", type=str, choices=["analyze", "verify", "learn"], required=True, help="Action to perform")
    parser.add_argument("--period_type", type=str, choices=["weekly", "monthly", "annual", "all"], default="monthly")
    parser.add_argument("--start_year", type=int, default=2024)
    parser.add_argument("--end_year", type=int, default=2024)
    parser.add_argument("--meta_label", type=str, default="Current-Cycle", help="Label for MetaRAG learning cycle")
    
    args = parser.parse_args()
    
    # 1. Generate Target Periods
    periods = []
    if args.period_type in ["weekly", "all"]:
        periods.extend(get_weeks(args.start_year, args.end_year))
    if args.period_type in ["monthly", "all"]:
        periods.extend(get_months(args.start_year, args.end_year))
    if args.period_type in ["annual", "all"]:
        periods.extend(get_years(args.start_year, args.end_year))
        
    print(f"🚀 TrendyBot: {args.action.upper()} mode for {len(periods)} periods ({args.start_year}-{args.end_year})...")
    
    # 2. Execute Action
    if args.action == "analyze":
        engine = TrendEyeEngine()
        for label, p_type, start, end in periods:
            engine.generate_trend_eye(p_type, start, end, label)
            
    elif args.action == "verify":
        engine = FutureEyeEngine()
        for label, p_type, start, end in periods:
            engine.evaluate_period(label)
            
    elif args.action == "learn":
        engine = MetaRAGEngine()
        engine.run_learning_cycle(args.meta_label)

if __name__ == "__main__":
    main()
