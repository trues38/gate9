import pandas as pd
import numpy as np
import json
from datetime import datetime, timedelta
from config_db import get_supabase_client

class TradingSimulator:
    def __init__(self, country="US", ticker="SPY", strategy_ids=None):
        self.supabase = get_supabase_client()
        self.country = country
        self.ticker = ticker
        self.strategy_ids = strategy_ids or [] # List of strategy IDs to run
        
        # Portfolio State
        self.nav = 1.0
        self.cash = 1.0
        self.position = 0.0 # Current position size (0.0 to 1.0)
        self.peak_nav = 1.0
        self.prev_close = None # For fallback if Open is missing
        
        # Data Cache
        self.macro_df = None
        self.price_df = None
        self.strategies = {}

    def load_data(self, start_date="2000-01-01", end_date="2025-12-31"):
        print(f"📥 Loading Data for {self.ticker} ({self.country})...")
        
        # 1. Load Strategies
        self._load_strategies()
        
        # 2. Load Macro (Global)
        # We fetch ALL macro data because we need continuous history
        self.macro_df = self._fetch_all_macro(start_date, end_date)
        
        # 3. Load Price
        self.price_df = self._fetch_all_price(start_date, end_date)
        
        print(f"   ✅ Loaded {len(self.macro_df)} macro rows, {len(self.price_df)} price rows.")

    def run(self):
        print(f"🚀 Starting Simulation for {self.ticker}...")
        
        # Merge Data for Simulation Loop
        # We need to align Macro(T) with Price(T) or Price(T+1) depending on country
        
        # Time Shift Logic
        # If Country is Asia (KR, JP, CN), we trade on T+1 based on Global News(T)
        # So we shift Macro Date +1 to match Price Date
        macro_shifted = self.macro_df.copy()
        if self.country in ["KR", "JP", "CN"]:
            print(f"   🌏 Applying +1 Day Shift for {self.country}...")
            macro_shifted['date'] = macro_shifted['date'] + timedelta(days=1)
            
        # Merge Price and Macro Data
        # Inner join to ensure we have both price and signal for the day
        print(f"   🐛 Debug Merge: Price {len(self.price_df)} rows ({self.price_df['date'].min()} to {self.price_df['date'].max()})")
        print(f"   🐛 Debug Merge: Macro {len(macro_shifted)} rows ({macro_shifted['date'].min()} to {macro_shifted['date'].max()})") # Use macro_shifted for debug print
        
        sim_data = pd.merge(
            self.price_df, 
            macro_shifted, # Use macro_shifted here
            on='date', 
            how='inner', 
            suffixes=('_price', '_macro')
        ).sort_values('date')

        print(f"   🐛 Debug Merge: Result {len(sim_data)} rows")
        
        if sim_data.empty:
            print("   ❌ Merge resulted in empty DataFrame! Check date alignment.")
            return
        
        trades_log = []
        portfolio_log = []
        
        for idx, row in sim_data.iterrows():
            current_date = row['date']
            
            # --- DEBUG: Inspect First 5 Rows ---
            if idx < 5:
                print(f"   🐛 Row {idx} ({current_date}): Keys={list(row.keys())}")
                print(f"      Z={row.get('zscore')}, dZ={row.get('delta_z')}, Open={row.get('open')}")
            # -----------------------------------

            # 1. Generate Signal
            signal = self._decide_signal(row)
            
            if idx < 5:
                 print(f"      Decision: {signal['decision']}")
            
            # 2. Execute Trade
            # Entry: Open (or Prev Close if missing), Exit: Close
            daily_ret = 0.0
            trade_info = None
            
            current_close = row.get('close')
            
            if signal['decision'] != "HOLD":
                entry_price = row.get('open')
                exit_price = current_close
                
                # Fallback: If Open is missing, use Prev Close
                if (entry_price is None or pd.isna(entry_price)) and self.prev_close is not None:
                    entry_price = self.prev_close
                
                # Check for valid price data
                if entry_price is not None and exit_price is not None and not pd.isna(entry_price) and not pd.isna(exit_price) and entry_price > 0:
                    raw_ret = (exit_price - entry_price) / entry_price
                    
                    if signal['decision'] == "LONG":
                        daily_ret = raw_ret
                    elif signal['decision'] == "SHORT":
                        daily_ret = -raw_ret
                        
                    # Evaluation Layer Metrics
                    holding_period = 1 # Intraday for now
                    realized_pnl = daily_ret * self.nav # Approx PnL impact
                    
                    trade_info = {
                        "trade_date": current_date.strftime("%Y-%m-%d"),
                        "entry_date": current_date.strftime("%Y-%m-%d"),
                        "exit_date": current_date.strftime("%Y-%m-%d"),
                        "ticker": self.ticker,
                        "strategy_id": signal['strategy_id'],
                        "signal_type": signal['decision'],
                        "raw_signal_value": signal['value'],
                        "decision": signal['decision'],
                        "entry_price": entry_price,
                        "exit_price": exit_price,
                        "return_1d": daily_ret,
                        "return_pct": daily_ret,
                        "holding_period": holding_period,
                        "realized_pnl": realized_pnl,
                        "metadata": json.dumps(signal['meta'])
                    }
                    trades_log.append(trade_info)
                else:
                    pass

            # Update Prev Close for next iteration
            if current_close is not None and not pd.isna(current_close):
                self.prev_close = current_close

            # 3. Update NAV
            if signal['decision'] != "HOLD":
                self.nav *= (1 + daily_ret)
            
            # Update Drawdown
            self.peak_nav = max(self.peak_nav, self.nav)
            drawdown = (self.nav - self.peak_nav) / self.peak_nav
            
            # Calculate Rolling Sharpe (Simple approx using recent returns)
            # We need history of returns for this.
            # For efficiency, we can't look back too far every loop.
            # Let's assume 0 for now or implement a window if needed.
            sharpe = 0.0 
            
            portfolio_log.append({
                "date": current_date.strftime("%Y-%m-%d"),
                "ticker": self.ticker,
                "strategy_id": "COMBINED" if len(self.strategy_ids) > 1 else self.strategy_ids[0],
                "active_strategy": signal.get('strategy_id'),
                "nav": self.nav,
                "daily_return": daily_ret,
                "drawdown": drawdown,
                "sharpe_ratio": sharpe,
                "position_size": 1.0 if signal['decision'] != "HOLD" else 0.0,
                "metadata": json.dumps({"active_strategy": signal.get('strategy_id')})
            })

        # 4. Save Logs
        self._save_logs(trades_log, portfolio_log)
        print(f"   🏁 Simulation Complete. Final NAV: {self.nav:.4f}")

    def _decide_signal(self, row):
        # Check all active strategies
        # For now, simple logic: First strategy that triggers wins
        # Or if multiple trigger? User said "Strategy A/B 조합".
        # Let's prioritize: If ANY strategy says LONG, we LONG.
        # If ANY says SHORT, we SHORT.
        # If Conflict? HOLD.
        
        vote_long = False
        vote_short = False
        triggered_strategy = None
        signal_val = 0.0
        meta = {}
        
        for st_id, rules in self.strategies.items():
            # Check Entry
            entry_cond = rules.get('entry_rule', {})
            # Parse condition string (e.g. "abs(zscore) >= 2.0")
            # We need a safe evaluator or parser.
            # Given the simple nature, let's implement specific handlers based on ID
            
            is_hit = False
            val = 0.0
            
            zscore = row.get('zscore') or 0.0
            delta_z = row.get('delta_z') or 0.0
            noise = row.get('noise_rate') or 0.0
            headlines = row.get('headline_count') or 0
            
            # --- Hardcoded Logic for the 2 Strategies (Safest) ---
            if st_id == "ZSCORE_2_BREAKOUT":
                if abs(zscore) >= 2.0:
                    # Filter
                    if noise <= 0.3 and headlines >= 10:
                        is_hit = True
                        val = zscore
                        
            elif st_id == "DELTAZ_2_REVERSAL":
                if abs(delta_z) >= 2.0:
                    if noise <= 0.2:
                        is_hit = True
                        val = delta_z
            
            if is_hit:
                triggered_strategy = st_id
                signal_val = val
                meta = {"zscore": zscore, "delta_z": delta_z}
                
                # Determine Direction
                # Usually Z>2 is Long (Momentum) or Short (Mean Rev)?
                # User said: "ZSCORE_2_BREAKOUT" -> "Momentum" -> If Z>2 Long, Z<-2 Short?
                # User said: "abs(zscore) >= 2.0".
                # Let's assume Direction follows Sign of Z.
                if val > 0:
                    vote_long = True
                else:
                    vote_short = True
                    
        if vote_long and not vote_short:
            return {"decision": "LONG", "strategy_id": triggered_strategy, "value": signal_val, "meta": meta}
        elif vote_short and not vote_long:
            return {"decision": "SHORT", "strategy_id": triggered_strategy, "value": signal_val, "meta": meta}
        else:
            return {"decision": "HOLD", "strategy_id": None, "value": 0.0, "meta": {}}

    def _load_strategies(self):
        # Fetch from DB
        res = self.supabase.table("backtest_strategies").select("*").execute()
        for st in res.data:
            if not self.strategy_ids or st['strategy_id'] in self.strategy_ids:
                # Parse JSON rules
                st['entry_rule'] = json.loads(st['entry_rule']) if isinstance(st['entry_rule'], str) else st['entry_rule']
                self.strategies[st['strategy_id']] = st
        print(f"   📋 Loaded {len(self.strategies)} strategies.")

    def _fetch_all_macro(self, start, end):
        # Select only necessary columns to reduce payload and avoid timeouts
        columns = "date, zscore, delta_z, noise_rate, headline_count"
        return self._fetch_with_pagination("preprocess_daily", {"country": "GLOBAL"}, start, end, columns=columns)

    def _fetch_all_price(self, start, end):
        # Select only necessary columns
        columns = "date, open, close"
        return self._fetch_with_pagination("ingest_prices", {"ticker": self.ticker}, start, end, columns=columns)

    def _fetch_with_pagination(self, table, filters, start, end, columns="*"):
        import time
        all_data = []
        limit = 200 # Reduced to 200 for safety
        current_start = start
        
        while True:
            retries = 5 # Increased retries
            for attempt in range(retries):
                try:
                    query = self.supabase.table(table).select(columns)
                    
                    for k, v in filters.items():
                        query = query.eq(k, v)
                    
                    if all_data:
                        last_date = all_data[-1]['date']
                        res = query.gt("date", last_date)\
                            .lte("date", end)\
                            .order("date")\
                            .limit(limit)\
                            .execute()
                    else:
                        res = query.gte("date", current_start)\
                            .lte("date", end)\
                            .order("date")\
                            .limit(limit)\
                            .execute()
                    
                    if not res.data:
                        return pd.DataFrame(all_data) if all_data else pd.DataFrame()
                        
                    all_data.extend(res.data)
                    
                    if len(res.data) < limit:
                        df = pd.DataFrame(all_data)
                        if not df.empty:
                            df['date'] = pd.to_datetime(df['date'])
                        return df
                        
                    time.sleep(0.1) # Throttle
                    break 
                    
                except Exception as e:
                    print(f"   ⚠️ Error fetching {table} (after {all_data[-1]['date'] if all_data else start}, attempt {attempt+1}/{retries}): {e}")
                    if attempt < retries - 1:
                        time.sleep(2 ** attempt)
                    else:
                        print(f"   ❌ Failed to fetch {table} after retries.")
                        raise e
        return pd.DataFrame(all_data)

    def _save_logs(self, trades, portfolio):
        # Batch insert
        if trades:
            self._batch_insert("backtest_trades", trades)
        if portfolio:
            self._batch_insert("backtest_portfolio", portfolio)

    def _batch_insert(self, table, data):
        import time
        batch_size = 500 # Reduced batch size
        for i in range(0, len(data), batch_size):
            batch = data[i:i+batch_size]
            retries = 3
            for attempt in range(retries):
                try:
                    self.supabase.table(table).upsert(batch).execute()
                    break
                except Exception as e:
                    print(f"   ⚠️ Error saving to {table} (batch {i}, attempt {attempt+1}): {e}")
                    time.sleep(1)

if __name__ == "__main__":
    # Test Run
    sim = TradingSimulator(country="US", ticker="SPY", strategy_ids=["ZSCORE_2_BREAKOUT", "DELTAZ_2_REVERSAL"])
    sim.load_data()
    sim.run()
