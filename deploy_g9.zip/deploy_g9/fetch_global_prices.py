import yfinance as yf
from config_db import get_supabase_client
import pandas as pd
from datetime import datetime

def fetch_and_save_prices(ticker, country):
    print(f"⬇️ Fetching price data for {ticker} ({country})...")
    
    # Fetch full history
    try:
        df = yf.download(ticker, start="2000-01-01", progress=False)
        if df.empty:
            print(f"   ❌ No data found for {ticker}")
            return

        # Reset index to get Date column
        df = df.reset_index()
        
        # Flatten MultiIndex columns if present
        # e.g. ('Close', 'SPY') -> 'Close'
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
            
        print(f"   📊 Flattened Columns: {df.columns}")
        
        # Standardize columns
        records = []
        for _, row in df.iterrows():
            try:
                # Date handling
                date_val = row['Date']
                if hasattr(date_val, 'strftime'):
                    date_val = date_val.strftime("%Y-%m-%d")
                else:
                    date_val = str(date_val).split()[0] # Fallback
                
                # Close handling
                close_val = row.get('Adj Close') or row.get('Close')
                
                if close_val is None:
                    # Fallback for weird casing
                    for c in df.columns:
                        if c.lower() == 'close': close_val = row[c]
                        if c.lower() == 'adj close' and close_val is None: close_val = row[c]
                
                if close_val is None:
                    continue # Skip if no price

                # Handle scalar extraction if it's a Series
                if isinstance(close_val, pd.Series): close_val = close_val.iloc[0]
                
                records.append({
                    "date": date_val,
                    "ticker": ticker,
                    "country": country,
                    "close": float(close_val),
                    "created_at": "now()"
                })
            except Exception as e:
                if _ == 0: print(f"   ❌ Row Error: {e}")
                continue

        if not records:
            print(f"   ⚠️ No valid records extracted for {ticker}")
            return

        # Batch Upsert
        supabase = get_supabase_client()
        batch_size = 1000
        print(f"   💾 Saving {len(records)} rows to 'ingest_prices'...")
        
        for i in range(0, len(records), batch_size):
            batch = records[i:i+batch_size]
            try:
                supabase.table("ingest_prices").upsert(batch, on_conflict="date, ticker").execute()
            except Exception as e:
                print(f"   ❌ Batch Error: {e}")
                
        print(f"   ✅ Saved {len(records)} rows for {ticker}.")
        
    except Exception as e:
        print(f"   ❌ Download Error: {e}")

if __name__ == "__main__":
    # Ticker Map
    targets = [
        ("^KS11", "KR"),      # KOSPI
        ("^N225", "JP"),      # Nikkei 225
        ("000001.SS", "CN"),  # Shanghai Composite
        ("SPY", "US")         # SPY (Update just in case)
    ]
    
    for t, c in targets:
        fetch_and_save_prices(t, c)
