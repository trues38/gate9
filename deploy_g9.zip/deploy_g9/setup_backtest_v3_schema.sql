-- G9 Macro Engine - Backtest V3 Schema
-- Run this in Supabase SQL Editor

-- 1. Backtest Results (Layer 1: Raw Signals)
CREATE TABLE IF NOT EXISTS public.backtest_results (
    id BIGSERIAL PRIMARY KEY,
    date DATE NOT NULL,
    ticker TEXT NOT NULL,
    strategy_id TEXT NOT NULL, -- The logic used (e.g., "PRIM_Z_SCORE_1.0")
    signal_type TEXT NOT NULL, -- 'LONG' or 'SHORT'
    signal_value FLOAT,        -- The Z-score or metric value
    fwd_return_1d FLOAT,
    fwd_return_5d FLOAT,
    fwd_return_20d FLOAT,
    is_valid_signal BOOLEAN DEFAULT TRUE,
    metadata JSONB,            -- Context
    created_at TIMESTAMPTZ DEFAULT timezone('utc', now()),
    UNIQUE(date, ticker, strategy_id)
);

-- 2. Backtest Patterns (Layer 2: Behavior)
CREATE TABLE IF NOT EXISTS public.backtest_patterns (
    pattern_id TEXT PRIMARY KEY,
    pattern_name TEXT NOT NULL,
    description TEXT,
    conditions JSONB,               -- e.g. {"regime": "CRISIS", "delta_z_min": 1.0}
    sample_count INT,
    win_rate FLOAT,
    avg_return FLOAT,
    max_drawdown FLOAT,
    volatility FLOAT,
    source_signals JSONB,          -- List of signal IDs or summary from backtest_results
    created_at TIMESTAMPTZ DEFAULT timezone('utc', now())
);

-- 3. Backtest Strategies (Layer 3: Actionable Rules)
CREATE TABLE IF NOT EXISTS public.backtest_strategies (
    strategy_id TEXT PRIMARY KEY,
    strategy_name TEXT NOT NULL,
    based_on_pattern_id TEXT REFERENCES public.backtest_patterns(pattern_id),

    entry_rule JSONB,              -- Buy conditions
    exit_rule JSONB,               -- Sell conditions
    risk_rule JSONB,               -- Stop loss / Risk management
    position_rule JSONB,           -- Position sizing

    win_rate FLOAT,
    avg_return FLOAT,
    max_drawdown FLOAT,
    volatility FLOAT,
    validation_score FLOAT,        -- Recent 6-12m validation score

    created_at TIMESTAMPTZ DEFAULT timezone('utc', now())
);

-- Enable RLS
ALTER TABLE backtest_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE backtest_patterns ENABLE ROW LEVEL SECURITY;
ALTER TABLE backtest_strategies ENABLE ROW LEVEL SECURITY;

-- Policies (Open access for service role)
CREATE POLICY "Enable all access for service role" ON backtest_results FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON backtest_patterns FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON backtest_strategies FOR ALL USING (true) WITH CHECK (true);
