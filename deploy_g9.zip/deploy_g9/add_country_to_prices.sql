-- Add country column to ingest_prices
-- Run this in Supabase SQL Editor

-- 1. Add column
ALTER TABLE ingest_prices ADD COLUMN IF NOT EXISTS country TEXT;

-- 2. Backfill existing data (Assuming mostly US/SPY for now)
UPDATE ingest_prices SET country = 'US' WHERE ticker = 'SPY' AND country IS NULL;
UPDATE ingest_prices SET country = 'US' WHERE country IS NULL; -- Default fallback

-- 3. Index (Optional but good for performance)
CREATE INDEX IF NOT EXISTS idx_ingest_prices_country ON ingest_prices(country);
