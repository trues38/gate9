-- G9 Macro Engine v2.0 Schema
-- Run this in Supabase SQL Editor to upgrade the database structure.

-- ⚠️ WARNING: This will DROP existing tables and data. 
-- Ensure you have backups if needed (though we can regenerate from raw data).

DROP TABLE IF EXISTS preprocess_daily CASCADE;
DROP TABLE IF EXISTS preprocess_weekly CASCADE;
DROP TABLE IF EXISTS preprocess_monthly CASCADE;
DROP TABLE IF EXISTS preprocess_annual CASCADE;

-- 1. Daily Preprocess Layer (The Source of Truth)
CREATE TABLE preprocess_daily (
    id BIGSERIAL PRIMARY KEY,
    date DATE NOT NULL,
    country TEXT NOT NULL,
    is_market_open BOOLEAN NOT NULL DEFAULT TRUE,
    is_holiday BOOLEAN NOT NULL DEFAULT FALSE,
    is_weekend BOOLEAN NOT NULL DEFAULT FALSE,
    headline_count INT DEFAULT 0,
    valid_headline_count INT DEFAULT 0,
    noise_rate FLOAT DEFAULT 0.0,
    zscore FLOAT,
    delta_z FLOAT,
    headline_raw JSONB,   -- Raw headlines from crawler
    headline_clean JSONB, -- Cleaned/Filtered headlines
    sources JSONB,        -- Source metadata
    meta_flags JSONB,     -- e.g. {"is_crisis": true, "is_fed_day": false}
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(date, country)
);

-- 2. Weekly Summary Layer (Derived from Daily)
CREATE TABLE preprocess_weekly (
    id BIGSERIAL PRIMARY KEY,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    country TEXT NOT NULL,
    auto_summary JSONB,       -- Structured summary (No LLM)
    llm_report_md TEXT,       -- LLM Generated Markdown Report
    llm_summary_short TEXT,   -- LLM Generated Short Summary
    avg_zscore FLOAT,
    max_delta_z FLOAT,
    dominant_regime TEXT,     -- e.g. "PANIC", "BOOM"
    dominant_bias TEXT,       -- e.g. "BEARISH", "BULLISH"
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(start_date, end_date, country)
);

-- 3. Monthly Summary Layer (Derived from Weekly/Daily)
CREATE TABLE preprocess_monthly (
    id BIGSERIAL PRIMARY KEY,
    year INT NOT NULL,
    month INT NOT NULL,
    country TEXT NOT NULL,
    auto_summary JSONB,
    llm_report_md TEXT,
    llm_summary_short TEXT,
    avg_zscore FLOAT,
    max_delta_z FLOAT,
    dominant_regime TEXT,
    dominant_bias TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(year, month, country)
);

-- 4. Annual Summary Layer (Derived from Monthly)
CREATE TABLE preprocess_annual (
    id BIGSERIAL PRIMARY KEY,
    year INT NOT NULL,
    country TEXT NOT NULL,
    auto_summary JSONB,
    llm_report_md TEXT,
    llm_summary_short TEXT,
    avg_zscore FLOAT,
    max_delta_z FLOAT,
    dominant_regime TEXT,
    dominant_bias TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(year, country)
);

-- Enable RLS
ALTER TABLE preprocess_daily ENABLE ROW LEVEL SECURITY;
ALTER TABLE preprocess_weekly ENABLE ROW LEVEL SECURITY;
ALTER TABLE preprocess_monthly ENABLE ROW LEVEL SECURITY;
ALTER TABLE preprocess_annual ENABLE ROW LEVEL SECURITY;

-- Create Policies (Adjust as needed for your access model)
CREATE POLICY "Enable all access for service role" ON preprocess_daily FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON preprocess_weekly FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON preprocess_monthly FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON preprocess_annual FOR ALL USING (true) WITH CHECK (true);
