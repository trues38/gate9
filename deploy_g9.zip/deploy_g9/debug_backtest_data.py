from backtest_engine import BacktestEngine
import pandas as pd

def debug_data():
    engine = BacktestEngine(market_ticker="SPY", market_country="US", macro_country="GLOBAL")
    
    print("🔍 Debugging Backtest Data (2000-2025)...")
    
    # 1. Fetch Macro
    macro = engine._fetch_macro_data("2000-01-01", "2025-12-31")
    print(f"   📊 Macro Rows (GLOBAL): {len(macro)}")
    if macro:
        print(f"      First: {macro[0]}")
        print(f"      Last:  {macro[-1]}")
        
    # 2. Fetch Price
    price = engine._fetch_price_data("2000-01-01", "2025-12-31", "SPY")
    print(f"   📊 Price Rows (SPY): {len(price)}")
    if price:
        print(f"      First: {price[0]}")
        print(f"      Last:  {price[-1]}")
        
    # 3. Merge Check
    if macro and price:
        df_m = pd.DataFrame(macro)
        df_p = pd.DataFrame(price)
        df_m['date'] = pd.to_datetime(df_m['date'])
        df_p['date'] = pd.to_datetime(df_p['date'])
        
        merged = pd.merge(df_m, df_p, on='date', how='inner')
        print(f"   🤝 Merged Rows: {len(merged)}")
        
        if not merged.empty:
            print(f"      Sample: {merged.iloc[0].to_dict()}")
            
            # Check Z-Score Distribution
            high_z = merged[merged['zscore'] > 1.0]
            print(f"      🔥 Rows with Z-Score > 1.0: {len(high_z)}")

if __name__ == "__main__":
    debug_data()
