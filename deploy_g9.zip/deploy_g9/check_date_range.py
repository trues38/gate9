from config_db import get_supabase_client

def check_date_range():
    supabase = get_supabase_client()
    print("📅 Checking 'ingest_news' date range...")
    
    try:
        # Min Date
        min_res = supabase.table("ingest_news").select("published_at").order("published_at", desc=False).limit(1).execute()
        min_date = min_res.data[0]['published_at'] if min_res.data else "None"
        
        # Max Date
        max_res = supabase.table("ingest_news").select("published_at").order("published_at", desc=True).limit(1).execute()
        max_date = max_res.data[0]['published_at'] if max_res.data else "None"
        
        print(f"   🗓️ Range: {min_date} ~ {max_date}")
        
    except Exception as e:
        print(f"   ❌ Error: {e}")

if __name__ == "__main__":
    check_date_range()
