import os
import json
from openai import OpenAI
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Initialize Client for OpenRouter
# Assumes OPENROUTER_API_KEY is set in .env
api_key = os.environ.get("OPENROUTER_API_KEY")

try:
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=api_key
    )
except Exception as e:
    print(f"⚠️ Warning: OpenAI Client initialization failed. {e}")
    client = None

def call_llm(prompt: str, input_data: dict, schema: str = None, model: str = "x-ai/grok-4.1-fast:free") -> dict:
    """
    Calls the LLM (via OpenRouter) with a prompt and input data, expecting a JSON response.
    Default model: x-ai/grok-4.1-fast:free
    """
    if not client:
        raise ValueError("OpenAI Client is not initialized. Please set OPENROUTER_API_KEY in .env")

    # Convert input data to string
    input_str = json.dumps(input_data, indent=2, default=str)
    
    # Construct System Message
    system_msg = "You are a Global Macro Expert AI (Trend-Eye)."
    if schema:
        system_msg += f"\nYou must output strictly valid JSON following this schema:\n{schema}"
    
    # Construct User Message
    user_msg = f"{prompt}\n\nInput Data:\n{input_str}"

    try:
        response = client.chat.completions.create(
            model=model,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": user_msg}
            ],
            response_format={"type": "json_object"},
            temperature=0.2, # Low temperature for consistent analysis
            extra_headers={
                "HTTP-Referer": "https://github.com/antigravity", # Optional: for OpenRouter rankings
                "X-Title": "TrendyBot"
            }
        )
        
        content = response.choices[0].message.content
        return json.loads(content)

    except Exception as e:
        print(f"❌ LLM Call Failed: {e}")
        return {}
