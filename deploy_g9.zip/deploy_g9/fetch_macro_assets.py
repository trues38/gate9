import yfinance as yf
import pandas as pd
from config_db import get_supabase_client
import time

def fetch_and_save_macro_assets():
    supabase = get_supabase_client()
    
    # Ticker Mapping
    assets = {
        "DX-Y.NYB": "Dollar Index",
        "GC=F": "Gold",
        "CL=F": "Crude Oil",
        "^TNX": "US 10Y Yield"
    }
    
    start_date = "2000-01-01"
    end_date = "2025-12-31"
    
    print(f"🚀 Fetching Macro Assets ({start_date} ~ {end_date})...")
    
    for ticker, name in assets.items():
        print(f"\n📥 Fetching {name} ({ticker})...")
        try:
            # Fetch from yfinance
            df = yf.download(ticker, start=start_date, end=end_date, progress=False)
            
            if df.empty:
                print(f"   ❌ No data found for {ticker}")
                continue
                
            print(f"   ✅ Fetched {len(df)} rows.")
            
            # Reset index to get Date column
            df = df.reset_index()
            
            # Flatten MultiIndex columns if present (yfinance often returns ('Open', 'Ticker'))
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            
            # Prepare for DB
            # Columns: Date, Open, High, Low, Close, Adj Close, Volume
            # DB expects: date, ticker, open, close, high, low, volume, adj_close (optional)
            
            db_rows = []
            for _, row in df.iterrows():
                # Handle potential NaN values
                # Ensure we are checking scalars, convert to float just in case
                open_val = row['Open']
                close_val = row['Close']
                
                # If it's still a Series (rare but possible), take the first element
                if isinstance(open_val, pd.Series): open_val = open_val.iloc[0]
                if isinstance(close_val, pd.Series): close_val = close_val.iloc[0]

                if pd.isna(open_val) or pd.isna(close_val):
                    continue
                
                # Safe extraction for other fields
                high_val = row['High']
                low_val = row['Low']
                vol_val = row['Volume']
                
                if isinstance(high_val, pd.Series): high_val = high_val.iloc[0]
                if isinstance(low_val, pd.Series): low_val = low_val.iloc[0]
                if isinstance(vol_val, pd.Series): vol_val = vol_val.iloc[0]

                db_rows.append({
                    "date": row['Date'].strftime("%Y-%m-%d"),
                    "ticker": ticker,
                    "open": float(open_val),
                    "close": float(close_val),
                    "high": float(high_val),
                    "low": float(low_val),
                    "volume": int(vol_val) if not pd.isna(vol_val) else 0
                })
            
            # Batch Insert
            batch_size = 1000
            total_saved = 0
            
            print(f"   💾 Saving to 'ingest_prices'...")
            for i in range(0, len(db_rows), batch_size):
                batch = db_rows[i:i+batch_size]
                try:
                    supabase.table("ingest_prices").upsert(batch).execute()
                    total_saved += len(batch)
                    print(f"      Saved {total_saved}/{len(db_rows)} rows...")
                except Exception as e:
                    print(f"      ⚠️ Error saving batch {i}: {e}")
                    time.sleep(1)
            
            print(f"   🎉 {name} Complete!")
            
        except Exception as e:
            print(f"   ❌ Critical Error processing {ticker}: {e}")

if __name__ == "__main__":
    fetch_and_save_macro_assets()
