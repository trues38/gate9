-- Reset Report Tables & Enforce Constraints
-- Run this in Supabase SQL Editor

-- 1. Wipe existing report data (Clean Slate)
TRUNCATE TABLE preprocess_weekly;
TRUNCATE TABLE preprocess_monthly;
TRUNCATE TABLE preprocess_annual;

-- 2. Drop old constraints if they exist (to avoid errors when re-adding)
ALTER TABLE preprocess_weekly DROP CONSTRAINT IF EXISTS preprocess_weekly_unique;
ALTER TABLE preprocess_monthly DROP CONSTRAINT IF EXISTS preprocess_monthly_unique;
ALTER TABLE preprocess_annual DROP CONSTRAINT IF EXISTS preprocess_annual_unique;

-- 3. Re-add Unique Constraints (The "Shield")
-- This ensures that future runs will UPDATE instead of DUPLICATE
ALTER TABLE preprocess_weekly ADD CONSTRAINT preprocess_weekly_unique UNIQUE (start_date, end_date, country);
ALTER TABLE preprocess_monthly ADD CONSTRAINT preprocess_monthly_unique UNIQUE (year, month, country);
ALTER TABLE preprocess_annual ADD CONSTRAINT preprocess_annual_unique UNIQUE (year, country);

-- 4. Verify
SELECT 'Tables Truncated and Constraints Enforced' as status;
