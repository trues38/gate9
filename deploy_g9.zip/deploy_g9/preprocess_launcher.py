import subprocess
import time
from concurrent.futures import ThreadPoolExecutor
import argparse

# Configuration
MAX_WORKERS = 3  # Reduced from 10 to prevent Supabase 502 Errors

def run_year_preprocessing(year, country_filter=None):
    """
    Runs preprocess_batch.py for a specific year.
    """
    start_date = f"{year}-01-01"
    end_date = f"{year}-12-31"
    
    print(f"🚀 [Launcher] Starting Preprocessing for Year {year}...")
    
    # Get absolute path to batch script
    import os
    script_dir = os.path.dirname(os.path.abspath(__file__))
    batch_script = os.path.join(script_dir, "preprocess_batch.py")
    
    # Added GLOBAL as per user request
    if country_filter:
        countries = [country_filter]
    else:
        # Dynamic Country Selection based on Year
        if year < 2000:
            # 1970-1999: Only US exists
            countries = ["US"]
        else:
            # 2000+: All countries exist
            countries = ["US", "KR", "JP", "CN", "GLOBAL"]
    
    for country in countries:
        # Call preprocess_batch.py
        cmd = [
            "python3", batch_script,
            "--start", start_date,
            "--end", end_date,
            "--country", country,
            "--workers", "5"
        ]
        try:
            subprocess.run(cmd, check=True)
        except:
            print(f"❌ Failed {country} for {year}")
            
    print(f"✅ [Launcher] Finished Year {year} (All Countries)")

def main():
    parser = argparse.ArgumentParser(description="Parallel Preprocessor Launcher (Distributed)")
    parser.add_argument("--start_year", type=int, default=2000, help="Start Year")
    parser.add_argument("--end_year", type=int, default=2025, help="End Year")
    parser.add_argument("--workers", type=int, default=MAX_WORKERS, help="Number of concurrent year-workers per node")
    parser.add_argument("--node_id", type=int, default=0, help="Node ID (0-indexed) for distributed processing")
    parser.add_argument("--total_nodes", type=int, default=1, help="Total number of nodes/computers")
    parser.add_argument("--only_country", type=str, default=None, help="Run for specific country only (e.g. US)")
    
    args = parser.parse_args()
    
    # 1. Generate all target years
    all_years = list(range(args.start_year, args.end_year + 1))
    
    # 2. Assign years to this node (Modulo Sharding)
    my_years = [y for y in all_years if y % args.total_nodes == args.node_id]
    
    print(f"🏎️  Starting Distributed Preprocessing (Node {args.node_id}/{args.total_nodes})")
    print(f"📅 Assigned Years: {my_years}")
    print(f"🔥 Local Concurrency: {args.workers} threads")
    if args.only_country:
        print(f"🎯 Target Country: {args.only_country}")
    
    if not my_years:
        print("   ⚠️ No years assigned to this node. Exiting.")
        return

    # Pass args to worker
    with ThreadPoolExecutor(max_workers=args.workers) as executor:
        # We need to pass the country arg to the function, but map takes one iterable.
        # So we'll use a lambda or partial, or just modify run_year_preprocessing to take the arg.
        # Better: modify run_year_preprocessing to accept country_filter.
        from functools import partial
        func = partial(run_year_preprocessing, country_filter=args.only_country)
        executor.map(func, my_years)
        
    print(f"🎉 Node {args.node_id} Finished!")

if __name__ == "__main__":
    main()
