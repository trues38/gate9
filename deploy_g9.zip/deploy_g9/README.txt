# G9 Distributed Preprocessing Package

## Setup
1. Install Python 3.8+
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Create a `.env` file in this directory with your Supabase credentials:
   ```
   SUPABASE_URL=your_url
   SUPABASE_KEY=your_key
   ```

## Running Distributed Processing
Run the following command on each machine (Node), changing the `--node_id` for each.

**Node 0:**
```bash
python3 preprocess_launcher.py --total_nodes 4 --node_id 0
```

**Node 1:**
```bash
python3 preprocess_launcher.py --total_nodes 4 --node_id 1
```

**Node 2:**
```bash
python3 preprocess_launcher.py --total_nodes 4 --node_id 2
```

**Node 3:**
```bash
python3 preprocess_launcher.py --total_nodes 4 --node_id 3
```
