from config_db import get_supabase_client

def check_prices():
    supabase = get_supabase_client()
    tickers = ["SPY", "^KS11", "^N225", "000001.SS"]
    
    print("💰 Checking 'ingest_prices' availability...")
    
    for ticker in tickers:
        try:
            # Count rows
            res = supabase.table("ingest_prices").select("date", count="exact").eq("ticker", ticker).limit(1).execute()
            count = res.count
            
            # Get Range
            min_res = supabase.table("ingest_prices").select("date").eq("ticker", ticker).order("date", desc=False).limit(1).execute()
            max_res = supabase.table("ingest_prices").select("date").eq("ticker", ticker).order("date", desc=True).limit(1).execute()
            
            start = min_res.data[0]['date'] if min_res.data else "N/A"
            end = max_res.data[0]['date'] if max_res.data else "N/A"
            
            print(f"   📈 {ticker:<10} | Rows: {count:<6} | Range: {start} ~ {end}")
            
        except Exception as e:
            print(f"   ❌ {ticker:<10} | Error: {e}")

if __name__ == "__main__":
    check_prices()
