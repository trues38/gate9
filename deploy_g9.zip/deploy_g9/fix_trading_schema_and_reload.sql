-- Comprehensive Fix for Trading Schema
-- Run this in Supabase SQL Editor

-- 1. Fix backtest_trades columns
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS ticker TEXT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS strategy_id TEXT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS signal_type TEXT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS decision TEXT;

-- 2. Fix backtest_portfolio columns
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS ticker TEXT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS strategy_id TEXT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS nav FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS daily_return FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS drawdown FLOAT;

-- 3. Reload Schema Cache
NOTIFY pgrst, 'reload config';
