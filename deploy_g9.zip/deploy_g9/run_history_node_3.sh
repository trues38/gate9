python3 preprocess_launcher.py --start_year 1970 --end_year 1999 --total_nodes 4 --node_id 3
