-- Update Schema for Backtest Evaluation Layer
-- Run this in Supabase SQL Editor

-- 1. Enhance backtest_trades
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS entry_date DATE;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS exit_date DATE;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS holding_period INT; -- Days held
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS return_pct FLOAT;   -- Percentage return (e.g. 0.05 for 5%)
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS realized_pnl FLOAT; -- Absolute PnL (e.g. 100.0)

-- 2. Enhance backtest_portfolio
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS sharpe_ratio FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS win_loss_ratio FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS active_strategy TEXT;

-- 3. Reload Schema Cache
NOTIFY pgrst, 'reload config';
