-- Run this in Supabase SQL Editor

-- 1. Weekly Table
CREATE TABLE IF NOT EXISTS preprocess_weekly (
    date DATE NOT NULL,
    country TEXT NOT NULL,
    zscore FLOAT,
    delta_z FLOAT,
    noise_rate FLOAT,
    headline_count INT,
    valid_headline_count INT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    PRIMARY KEY (date, country)
);

-- 2. Monthly Table
CREATE TABLE IF NOT EXISTS preprocess_monthly (
    date DATE NOT NULL,
    country TEXT NOT NULL,
    zscore FLOAT,
    delta_z FLOAT,
    noise_rate FLOAT,
    headline_count INT,
    valid_headline_count INT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    PRIMARY KEY (date, country)
);

-- 3. Annual Table
CREATE TABLE IF NOT EXISTS preprocess_annual (
    date DATE NOT NULL,
    country TEXT NOT NULL,
    zscore FLOAT,
    delta_z FLOAT,
    noise_rate FLOAT,
    headline_count INT,
    valid_headline_count INT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    PRIMARY KEY (date, country)
);

-- 4. Enable RLS (Optional but recommended)
ALTER TABLE preprocess_weekly ENABLE ROW LEVEL SECURITY;
ALTER TABLE preprocess_monthly ENABLE ROW LEVEL SECURITY;
ALTER TABLE preprocess_annual ENABLE ROW LEVEL SECURITY;

-- 5. Create Policy (Allow all for service role, or public if needed for testing)
CREATE POLICY "Enable all access for service role" ON preprocess_weekly FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON preprocess_monthly FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON preprocess_annual FOR ALL USING (true) WITH CHECK (true);
