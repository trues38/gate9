from config_db import get_supabase_client

def verify_backtest_table():
    supabase = get_supabase_client()
    print("🔍 Verifying 'backtest_results' table...")
    
    try:
        # Try to select from the table
        res = supabase.table("backtest_results").select("count", count="exact").limit(1).execute()
        print(f"   ✅ 'backtest_results' table exists. Current rows: {res.count}")
    except Exception as e:
        print(f"   ❌ Error accessing 'backtest_results': {e}")
        print("   👉 Please run 'setup_backtest_schema.sql' in Supabase SQL Editor.")

if __name__ == "__main__":
    verify_backtest_table()
