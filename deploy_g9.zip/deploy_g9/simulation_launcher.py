import argparse
from trading_simulator import TradingSimulator

def main():
    parser = argparse.ArgumentParser(description="G9 Trading Simulation Launcher")
    parser.add_argument("--country", type=str, required=True, help="Market Country (US, KR, JP, CN)")
    parser.add_argument("--ticker", type=str, required=True, help="Market Ticker (e.g. SPY, ^KS11)")
    
    args = parser.parse_args()
    
    # Define active strategies (Currently we run the 2 core ones)
    strategies = ["ZSCORE_2_BREAKOUT", "DELTAZ_2_REVERSAL"]
    
    print(f"🎮 Launching Simulation for {args.country} ({args.ticker})...")
    
    sim = TradingSimulator(
        country=args.country, 
        ticker=args.ticker, 
        strategy_ids=strategies
    )
    
    sim.load_data()
    sim.run()

if __name__ == "__main__":
    main()
