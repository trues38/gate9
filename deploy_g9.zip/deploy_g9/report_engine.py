import pandas as pd
import json
import numpy as np
from datetime import datetime, timedelta
from config_db import get_supabase_client
from typing import List, Dict, Any

class ReportEngine:
    def __init__(self):
        self.supabase = get_supabase_client()

    def run_pipeline(self, start_year=2000, end_year=2025, countries=None):
        if countries is None:
            countries = ["US", "KR", "JP", "CN", "GLOBAL"]
            
        for country in countries:
            print(f"🚀 Starting Report Pipeline for {country} ({start_year}-{end_year})...")
            # 1. Weekly
            self._process_period(start_year, end_year, country, "weekly")
            # 2. Monthly
            self._process_period(start_year, end_year, country, "monthly")
            # 3. Annual
            self._process_period(start_year, end_year, country, "annual")

    def _process_period(self, start_year, end_year, country, period_type):
        print(f"   Generating {period_type} reports...")
        
        # Fetch all daily data
        start_date = f"{start_year}-01-01"
        end_date = f"{end_year}-12-31"
        daily_data = self._fetch_daily_data(country, start_date, end_date)
        
        if not daily_data:
            print(f"   ⚠️ No daily data found for {country}")
            return

        df = pd.DataFrame(daily_data)
        df['date'] = pd.to_datetime(df['date'])
        df = df.sort_values('date')

        # Resample
        if period_type == "weekly":
            # W-MON: Weekly starting Monday
            grouper = df.groupby(pd.Grouper(key='date', freq='W-MON'))
            target_table = "preprocess_weekly"
        elif period_type == "monthly":
            grouper = df.groupby(pd.Grouper(key='date', freq='MS'))
            target_table = "preprocess_monthly"
        elif period_type == "annual":
            grouper = df.groupby(pd.Grouper(key='date', freq='AS'))
            target_table = "preprocess_annual"

        records = []
        for period_start, group in grouper:
            if group.empty: continue
            
            # Calculate Metrics
            summary_data = self._generate_auto_summary(group)
            
            # Prepare DB Record
            record = {
                "country": country,
                "auto_summary": json.dumps(summary_data['auto_summary']),
                "avg_zscore": summary_data['avg_zscore'],
                "max_delta_z": summary_data['max_delta_z'],
                "dominant_regime": summary_data['dominant_regime'],
                "dominant_bias": summary_data['dominant_bias'],
                "created_at": "now()"
            }
            
            # Set Keys based on table
            if period_type == "weekly":
                record['start_date'] = period_start.strftime("%Y-%m-%d")
                record['end_date'] = (period_start + timedelta(days=6)).strftime("%Y-%m-%d")
            elif period_type == "monthly":
                record['year'] = period_start.year
                record['month'] = period_start.month
            elif period_type == "annual":
                record['year'] = period_start.year
                
            records.append(record)

        # Batch Upsert
        if records:
            self._batch_upsert(target_table, records, period_type)
            print(f"   ✅ {period_type.capitalize()}: Generated {len(records)} reports.")

    def _generate_auto_summary(self, df: pd.DataFrame) -> Dict[str, Any]:
        """
        Generates structured summary without LLM.
        """
        # 1. Basic Stats
        avg_z = df['zscore'].mean()
        max_delta = df['delta_z'].abs().max()
        
        # 2. Dominant Regime/Bias
        # Simple Logic: 
        # Z < -1.5 => PANIC, Z > 1.5 => EUPHORIA, else NORMAL
        # Bias: Z > 0 => BULLISH, Z < 0 => BEARISH
        
        if avg_z < -1.5: regime = "PANIC"
        elif avg_z > 1.5: regime = "EUPHORIA"
        elif avg_z < -0.5: regime = "FEAR"
        elif avg_z > 0.5: regime = "GREED"
        else: regime = "NEUTRAL"
        
        bias = "BULLISH" if avg_z > 0 else "BEARISH"
        
        # 3. Key Events (Days with high impact)
        # Sort by abs(delta_z) descending
        events = []
        sorted_df = df.sort_values(by='delta_z', key=abs, ascending=False)
        for _, row in sorted_df.head(3).iterrows():
            events.append({
                "date": row['date'].strftime("%Y-%m-%d"),
                "zscore": row['zscore'],
                "delta_z": row['delta_z'],
                "headline_count": row['headline_count']
            })
            
        auto_summary = {
            "stats": {
                "avg_zscore": round(avg_z, 2),
                "max_delta_z": round(max_delta, 2),
                "total_headlines": int(df['headline_count'].sum())
            },
            "regime": regime,
            "bias": bias,
            "key_events": events
        }
        
        return {
            "auto_summary": auto_summary,
            "avg_zscore": avg_z,
            "max_delta_z": max_delta,
            "dominant_regime": regime,
            "dominant_bias": bias
        }

    def _fetch_daily_data(self, country, start_date, end_date):
        all_rows = []
        start = 0
        batch_size = 1000 # Supabase default max limit is often 1000
        while True:
            try:
                res = self.supabase.table("preprocess_daily")\
                    .select("date, zscore, delta_z, headline_count")\
                    .eq("country", country)\
                    .gte("date", start_date)\
                    .lte("date", end_date)\
                    .range(start, start + batch_size - 1)\
                    .execute()
                
                if not res.data:
                    break
                all_rows.extend(res.data)
                if len(res.data) < batch_size:
                    break
                start += batch_size
            except Exception as e:
                print(f"   ❌ Error fetching daily: {e}")
                break
        print(f"   📊 Fetched {len(all_rows)} daily rows for {country}.")
        return all_rows

    def _batch_upsert(self, table, records, period_type):
        batch_size = 100
        conflict_key = "start_date, end_date, country" if period_type == "weekly" else \
                       "year, month, country" if period_type == "monthly" else \
                       "year, country"
                       
        for i in range(0, len(records), batch_size):
            batch = records[i:i+batch_size]
            try:
                self.supabase.table(table).upsert(batch, on_conflict=conflict_key).execute()
            except Exception as e:
                print(f"   ❌ Error saving batch to {table}: {e}")

if __name__ == "__main__":
    engine = ReportEngine()
    engine.run_pipeline()
