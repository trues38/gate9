import os
import sys
from collections import defaultdict
from config_db import get_supabase_client

def clean_duplicates():
    print("🧹 Starting Duplicate Cleanup for GLOBAL...")
    supabase = get_supabase_client()
    
    # 1. Fetch all GLOBAL rows (id, date)
    # We need to handle pagination if there are many, but 10k is small enough for one go usually, 
    # but Supabase limit is often 1000. We need to paginate.
    
    all_rows = []
    start = 0
    batch_size = 1000
    
    while True:
        print(f"   Fetching batch {start}...")
        res = supabase.table("preprocess_daily")\
            .select("id, date")\
            .eq("country", "GLOBAL")\
            .range(start, start + batch_size - 1)\
            .execute()
            
        if not res.data:
            break
            
        all_rows.extend(res.data)
        start += batch_size
        if len(res.data) < batch_size:
            break
            
    print(f"📊 Total GLOBAL rows fetched: {len(all_rows)}")
    
    # 2. Find Duplicates
    date_map = defaultdict(list)
    for row in all_rows:
        date_map[row['date']].append(row['id'])
        
    duplicates_to_delete = []
    
    for date_str, ids in date_map.items():
        if len(ids) > 1:
            # Sort by ID (usually higher ID = newer, but we just need to keep one)
            # Let's keep the one with the highest ID (latest)
            ids.sort()
            to_remove = ids[:-1] # Keep last one
            duplicates_to_delete.extend(to_remove)
            print(f"   ⚠️ Duplicate found for {date_str}: {len(ids)} copies. Removing {len(to_remove)}.")
            
    # 3. Delete
    if not duplicates_to_delete:
        print("✅ No duplicates found.")
        return
        
    print(f"🔥 Deleting {len(duplicates_to_delete)} duplicate rows...")
    
    # Delete in batches
    chunk_size = 100
    for i in range(0, len(duplicates_to_delete), chunk_size):
        chunk = duplicates_to_delete[i:i+chunk_size]
        try:
            supabase.table("preprocess_daily").delete().in_("id", chunk).execute()
            print(f"   🗑️ Deleted batch {i}-{i+len(chunk)}")
        except Exception as e:
            print(f"   ❌ Delete failed: {e}")
            
    print("🎉 Cleanup Complete!")

if __name__ == "__main__":
    clean_duplicates()
