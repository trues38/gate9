-- FINAL FIX for All Missing Columns
-- Run this in Supabase SQL Editor to cure all PGRST204 errors.

-- 1. Backtest Trades Table
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS strategy_id TEXT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS ticker TEXT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS signal_type TEXT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS decision TEXT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS entry_date DATE;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS exit_date DATE;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS holding_period INT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS return_pct FLOAT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS realized_pnl FLOAT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS entry_price FLOAT;
ALTER TABLE backtest_trades ADD COLUMN IF NOT EXISTS exit_price FLOAT;

-- 2. Backtest Portfolio Table
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS strategy_id TEXT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS ticker TEXT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS nav FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS daily_return FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS drawdown FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS sharpe_ratio FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS win_loss_ratio FLOAT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS active_strategy TEXT;
ALTER TABLE backtest_portfolio ADD COLUMN IF NOT EXISTS position_size FLOAT; -- Added this just in case

-- 3. Reload Schema Cache (The most important step!)
NOTIFY pgrst, 'reload config';
