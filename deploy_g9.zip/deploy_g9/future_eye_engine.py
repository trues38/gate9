import pandas as pd
import json
from datetime import datetime, timedelta
from config_db import get_supabase_client
from llm_utils import call_llm
from trend_eye_engine import TrendEyeEngine # Reuse data loading logic

# --- SCHEMA ---
FUTURE_EYE_EVALUATION_SCHEMA = """
{
    "verified": true,
    "evaluation_summary": "string (Critique of the past analysis based on actual future data)",
    "accuracy_scores": {
        "tide_alignment": "float (0.0 to 1.0)",
        "oscillation_alignment": "float (0.0 to 1.0)",
        "flow_accuracy": "float (0.0 to 1.0)",
        "shockwave_alignment": "float (0.0 to 1.0)"
    },
    "missed_signals": ["string (Major events that were missed)"],
    "overestimated_signals": ["string (Events that were hyped but fizzled)"],
    "new_patterns": ["string (New cause-effect relationships observed)"],
    "correction_notes": ["string (Advice for the next Trend-Eye cycle)"]
}
"""

class FutureEyeEngine:
    def __init__(self):
        self.supabase = get_supabase_client()
        self.trend_engine = TrendEyeEngine() # Helper to load data

    def evaluate_period(self, period_label):
        """
        Evaluates a specific Trend-Eye record by looking at subsequent data.
        """
        print(f"🔮 Future-Eye: Verifying {period_label}...")

        # 1. Load the Past Prediction
        prediction_record = self._load_prediction(period_label)
        if not prediction_record:
            print(f"   ⚠️ No Trend-Eye record found for {period_label}")
            return

        # 2. Determine "Future" Period (The Verification Window)
        # For Weekly -> Verify with next 1 week
        # For Monthly -> Verify with next 1 month
        # For Annual -> Verify with next 3 months (or full year if available)
        
        period_type = prediction_record['period_type']
        start_date = prediction_record['raw_data_reference'].get('end_date', None) # Hack: we need the end date of the analysis
        
        # If raw_data_reference doesn't have dates (it was a simplified dict in v1), 
        # we might need to parse period_label or rely on DB timestamps.
        # Let's assume we can derive it or it's stored. 
        # For now, let's parse period_label if needed, but better to fetch from DB if we stored it.
        # In trend_eye_engine.py, we didn't explicitly store start/end in columns, only in JSON or derived.
        # Let's infer for now.
        
        eval_start, eval_end = self._get_evaluation_window(period_label, period_type)
        if not eval_start:
            return

        print(f"   📅 Evaluation Window: {eval_start} ~ {eval_end}")

        # 3. Load Actual Future Data
        future_data = self.trend_engine._load_data_bundle(eval_start, eval_end)
        if not future_data['key_prices']:
            print("   ⚠️ Insufficient future data for verification.")
            return

        # 4. Construct LLM Input
        llm_input = {
            "task": "VERIFICATION",
            "past_analysis": {
                "summary": prediction_record['trend_summary'],
                "drivers": prediction_record['market_drivers'],
                "asset_trend": prediction_record['asset_trend'],
                "risk_signals": prediction_record['risk_signals']
            },
            "actual_future_data": future_data
        }

        # 5. Call LLM
        print("   🧠 Consulting Future-Eye LLM...")
        evaluation = call_llm(
            prompt="Compare the Past Analysis with the Actual Future Data. Score the accuracy strictly.",
            input_data=llm_input,
            schema=FUTURE_EYE_EVALUATION_SCHEMA
        )

        if not evaluation:
            print("   ❌ LLM returned empty evaluation.")
            return

        # 6. Update DB
        self._save_evaluation(prediction_record['id'], evaluation)
        print("   ✅ Verification Saved.")

    def _load_prediction(self, period_label):
        try:
            res = self.supabase.table("trend_eye_insights")\
                .select("*")\
                .eq("period", period_label)\
                .limit(1)\
                .execute()
            return res.data[0] if res.data else None
        except Exception as e:
            print(f"   ⚠️ Error loading prediction: {e}")
            return None

    def _get_evaluation_window(self, period_label, period_type):
        # Simple parsing logic
        try:
            if period_type == 'monthly':
                # Label: YYYY-MM
                dt = datetime.strptime(period_label, "%Y-%m")
                # Evaluate using the NEXT month
                next_month = dt.replace(day=28) + timedelta(days=4)
                eval_start = (dt.replace(day=28) + timedelta(days=4)).replace(day=1).strftime("%Y-%m-%d")
                
                # End of next month
                next_next = next_month.replace(day=28) + timedelta(days=4)
                eval_end = (next_next.replace(day=1) - timedelta(days=1)).strftime("%Y-%m-%d")
                return eval_start, eval_end
                
            elif period_type == 'weekly':
                # Label: YYYY-Wxx
                # Parsing ISO week is tricky without library, let's assume standard format
                # For simplicity in this prototype, let's just use the 'created_at' + 7 days if we could.
                # But let's try to parse.
                year = int(period_label.split('-')[0])
                week = int(period_label.split('-W')[1])
                start_dt = datetime.strptime(f'{year}-W{week}-1', "%Y-W%W-%w")
                end_dt = start_dt + timedelta(days=6)
                
                # Verify with NEXT week
                eval_start = (end_dt + timedelta(days=1)).strftime("%Y-%m-%d")
                eval_end = (end_dt + timedelta(days=7)).strftime("%Y-%m-%d")
                return eval_start, eval_end
                
            elif period_type == 'annual':
                year = int(period_label)
                # Verify with Q1 of next year? Or full next year?
                # User said "1 month lag". Let's verify with the FIRST MONTH of the next period?
                # Or if it's an annual report, we verify it after a year?
                # Let's assume we verify it with the NEXT YEAR's data.
                eval_start = f"{year+1}-01-01"
                eval_end = f"{year+1}-12-31"
                return eval_start, eval_end

        except Exception as e:
            print(f"   ⚠️ Date parsing error: {e}")
            return None, None
        
        return None, None

    def _save_evaluation(self, record_id, evaluation):
        try:
            self.supabase.table("trend_eye_insights")\
                .update({"evaluation_placeholder": json.dumps(evaluation)})\
                .eq("id", record_id)\
                .execute()
        except Exception as e:
            print(f"   ❌ Error saving evaluation: {e}")

if __name__ == "__main__":
    engine = FutureEyeEngine()
    # engine.evaluate_period("2024-01") 
