from preprocess_aggregator import Aggregator

if __name__ == "__main__":
    print("🏎️  Starting Aggregation Pipeline (Weekly/Monthly/Annual)...")
    agg = Aggregator()
    agg.run_all()
    print("🎉 Aggregation Complete!")
