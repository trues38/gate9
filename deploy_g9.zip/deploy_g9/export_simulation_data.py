import pandas as pd
from config_db import get_supabase_client
import os

def fetch_all_data(table_name, batch_size=1000):
    supabase = get_supabase_client()
    print(f"📥 Fetching all data from '{table_name}'...")
    
    all_rows = []
    last_id = 0
    
    while True:
        try:
            # Fetch next batch based on ID
            res = supabase.table(table_name)\
                .select("*")\
                .gt("id", last_id)\
                .order("id", desc=False)\
                .limit(batch_size)\
                .execute()
            
            data = res.data
            if not data:
                break
                
            all_rows.extend(data)
            last_id = data[-1]['id']
            print(f"   🔹 Fetched {len(all_rows)} rows... (Last ID: {last_id})")
            
            if len(data) < batch_size:
                break
                
        except Exception as e:
            print(f"   ⚠️ Error fetching batch: {e}")
            break
            
    return pd.DataFrame(all_rows)

def main():
    # 1. Export Portfolio
    df_portfolio = fetch_all_data("backtest_portfolio")
    if not df_portfolio.empty:
        filename = "backtest_portfolio.csv"
        df_portfolio.to_csv(filename, index=False)
        print(f"✅ Saved {len(df_portfolio)} rows to {filename}")
    else:
        print("⚠️ No data found in backtest_portfolio")

    # 2. Export Trades
    df_trades = fetch_all_data("backtest_trades")
    if not df_trades.empty:
        filename = "backtest_trades.csv"
        df_trades.to_csv(filename, index=False)
        print(f"✅ Saved {len(df_trades)} rows to {filename}")
    else:
        print("⚠️ No data found in backtest_trades")

    print("\n🎉 Export Complete! You can now analyze these CSV files in Excel.")

if __name__ == "__main__":
    main()
