import os
import sys
import json
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional

# Flat import for deployment package
from config_db import get_supabase_client

class BacktestEngine:
    def __init__(self, market_ticker: str = "SPY", market_country: str = "US", macro_country: str = "GLOBAL"):
        self.supabase = get_supabase_client()
        self.market_ticker = market_ticker
        self.market_country = market_country
        self.macro_country = macro_country

    def run_backtest(self, start_date: str, end_date: str, strategy_config: Dict):
        """
        Runs a backtest for a specific strategy configuration.
        """
        strategy_id = strategy_config.get("id")
        print(f"📉 Starting Backtest: {strategy_id} ({start_date} ~ {end_date}) | Market: {self.market_country} ({self.market_ticker}) | Signal: {self.macro_country}...")
        
        # 1. Fetch Macro Data (Signals)
        macro_data = self._fetch_macro_data(start_date, end_date)
        if not macro_data:
            print("   ⚠️ No macro data found.")
            return

        # 2. Fetch Price Data (Returns)
        # Fetch extra buffer for forward returns
        end_dt = datetime.strptime(end_date, "%Y-%m-%d")
        buffer_date = (end_dt + timedelta(days=30)).strftime("%Y-%m-%d")
        
        price_data = self._fetch_price_data(start_date, buffer_date, self.market_ticker)
        if not price_data:
            print("   ⚠️ No price data found.")
            return
            
        # Convert to DataFrame
        df_macro = pd.DataFrame(macro_data)
        df_price = pd.DataFrame(price_data)
        
        # Ensure dates are datetime
        df_macro['date'] = pd.to_datetime(df_macro['date'])
        df_price['date'] = pd.to_datetime(df_price['date'])
        
        # Sort
        df_macro = df_macro.sort_values('date')
        df_price = df_price.sort_values('date')
        
        # --- TIME ZONE ADJUSTMENT (The "+1 Day" Rule) ---
        # For Asian markets (KR, JP, CN), US/Global news from Day T 
        # can only be traded on Day T+1.
        # So we shift the Macro Date forward by 1 day to match with Price Date.
        if self.market_country in ["KR", "JP", "CN"]:
            print(f"   🌏 Applying +1 Day Shift for {self.market_country} (Signal: {self.macro_country})...")
            df_macro['date'] = df_macro['date'] + timedelta(days=1)
        
        # Calculate Forward Returns on Price Data first
        df_price['ret_1d'] = df_price['close'].pct_change(periods=1).shift(-1)
        df_price['ret_5d'] = df_price['close'].pct_change(periods=5).shift(-5)
        df_price['ret_20d'] = df_price['close'].pct_change(periods=20).shift(-20)
        
        # Merge
        # We use inner join on date to match signal with that day's price/future return
        merged = pd.merge(df_macro, df_price[['date', 'ret_1d', 'ret_5d', 'ret_20d', 'close']], on='date', how='inner')
        
        results = []
        
        for _, row in merged.iterrows():
            signal = self._evaluate_signal(row, strategy_config)
            
            if signal:
                results.append({
                    "date": row['date'].strftime("%Y-%m-%d"),
                    "ticker": self.market_ticker,
                    "strategy_id": strategy_id,
                    "signal_type": signal['type'], # LONG / SHORT
                    "signal_value": signal['value'], # The value that triggered it (e.g. zscore)
                    "fwd_return_1d": row['ret_1d'],
                    "fwd_return_5d": row['ret_5d'],
                    "fwd_return_20d": row['ret_20d'],
                    "is_valid_signal": True,
                    "metadata": json.dumps(strategy_config.get("params", {})),
                    "created_at": "now()"
                })
                
        # 3. Save Results
        if results:
            self._save_results(results)
            print(f"   ✅ Saved {len(results)} signals for {strategy_id}.")
        else:
            print(f"   ℹ️ No signals generated for {strategy_id}.")

    def _evaluate_signal(self, row, config) -> Optional[Dict]:
        """
        Evaluates the strategy logic against a single row of data.
        Returns dict {'type': 'LONG'|'SHORT', 'value': float} or None.
        """
        st_type = config.get("type")
        params = config.get("params", {})
        
        # Extract Data
        zscore = row.get('zscore') or 0.0
        delta_z = row.get('delta_z') or 0.0
        
        # Noise Filter
        noise_rate = row.get('noise_rate') or 0.0
        headline_count = row.get('headline_count') or 0
        
        if params.get("filter_noise", False):
            if noise_rate > 0.7 or headline_count < 5:
                return None

        # 1. Z-Score Strategy
        if st_type == "Z_SCORE":
            threshold = params.get("threshold", 1.0)
            if zscore > threshold:
                return {'type': 'LONG', 'value': zscore}
            elif zscore < -threshold:
                return {'type': 'SHORT', 'value': zscore}
                
        # 2. Delta-Z Strategy
        elif st_type == "DELTA_Z":
            threshold = params.get("threshold", 1.5)
            if delta_z > threshold:
                return {'type': 'LONG', 'value': delta_z}
            elif delta_z < -threshold:
                return {'type': 'SHORT', 'value': delta_z}
                
        return None

    def _fetch_macro_data(self, start_date, end_date):
        all_data = []
        offset = 0
        limit = 1000
        
        while True:
            try:
                res = self.supabase.table("preprocess_daily")\
                    .select("date, zscore, delta_z, noise_rate, headline_count")\
                    .eq("country", self.macro_country)\
                    .gte("date", start_date)\
                    .lte("date", end_date)\
                    .order("date", desc=False)\
                    .range(offset, offset + limit - 1)\
                    .execute()
                
                if not res.data:
                    break
                    
                all_data.extend(res.data)
                
                if len(res.data) < limit:
                    break
                    
                offset += limit
            except Exception as e:
                print(f"   ❌ Error fetching macro data (offset {offset}): {e}")
                break
                
        return all_data

    def _fetch_price_data(self, start_date, end_date, ticker):
        all_data = []
        offset = 0
        limit = 1000
        
        while True:
            try:
                res = self.supabase.table("ingest_prices")\
                    .select("date, close")\
                    .eq("ticker", ticker)\
                    .gte("date", start_date)\
                    .lte("date", end_date)\
                    .order("date", desc=False)\
                    .range(offset, offset + limit - 1)\
                    .execute()
                
                if not res.data:
                    break
                    
                all_data.extend(res.data)
                
                if len(res.data) < limit:
                    break
                    
                offset += limit
            except Exception as e:
                print(f"   ❌ Error fetching price data (offset {offset}): {e}")
                break
                
        return all_data

    def _save_results(self, results):
        try:
            # Batch insert
            batch_size = 100
            for i in range(0, len(results), batch_size):
                batch = results[i:i+batch_size]
                # Handle NaN for JSON (Pandas NaN is not valid JSON)
                cleaned_batch = []
                for item in batch:
                    if pd.isna(item['fwd_return_1d']): item['fwd_return_1d'] = None
                    if pd.isna(item['fwd_return_5d']): item['fwd_return_5d'] = None
                    if pd.isna(item['fwd_return_20d']): item['fwd_return_20d'] = None
                    cleaned_batch.append(item)
                    
                self.supabase.table("backtest_results").upsert(cleaned_batch, on_conflict="date, ticker, strategy_id").execute()
        except Exception as e:
            print(f"   ❌ Error saving backtest results: {e}")
