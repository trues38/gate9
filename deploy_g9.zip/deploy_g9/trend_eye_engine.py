import pandas as pd
import json
from datetime import datetime, timedelta
from config_db import get_supabase_client
from llm_utils import call_llm

# --- SCHEMAS ---
TREND_EYE_SCHEMA = """
{
    "macro_regime": "string (e.g., 'Goldilocks', 'Stagflation', 'Reflation', 'Deflation')",
    "macro_bias_score": "float (-10.0 to +10.0, where +10 is extreme bullish risk-on)",
    "trend_summary": "string (Concise summary of the macro landscape)",
    "market_drivers": [
        {"driver_name": "string", "direction": "UP/DOWN/NEUTRAL", "evidence": "string"}
    ],
    "country_strength": {
        "US": "int (-5 to +5)",
        "KR": "int (-5 to +5)",
        "JP": "int (-5 to +5)",
        "CN": "int (-5 to +5)"
    },
    "asset_trend": {
        "equities": "UP/DOWN/NEUTRAL",
        "gold": "UP/DOWN/NEUTRAL",
        "oil": "UP/DOWN/NEUTRAL",
        "bonds": "UP/DOWN/NEUTRAL (Price direction, inverse of yield)",
        "dollar": "UP/DOWN/NEUTRAL"
    },
    "risk_signals": ["string"],
    "opportunity_signals": ["string"],
    "recommended_positions": {
        "long_candidates": ["string"],
        "short_candidates": ["string"]
    },
    "confidence": "float (0.0 to 1.0)"
}
"""

class TrendEyeEngine:
    def __init__(self):
        self.supabase = get_supabase_client()

    def generate_trend_eye(self, period_type, start_date, end_date, period_label):
        """
        Main entry point to generate Trend-Eye analysis.
        period_type: 'weekly' | 'monthly' | 'annual'
        period_label: e.g., '2025-W01', '2025-01', '2025'
        """
        print(f"👁️ Generating Trend-Eye for {period_label} ({start_date} ~ {end_date})...")

        # 1. Load Data
        data_bundle = self._load_data_bundle(start_date, end_date)
        
        # 2. Load MetaRAG Rules (The "Brain")
        meta_rules = self._load_meta_rules()

        # 3. Construct LLM Input
        llm_input = {
            "period_type": period_type,
            "period_range": {"start": start_date, "end": end_date},
            "data": data_bundle,
            "meta_guidance": meta_rules
        }

        # 4. Call LLM
        print("   🧠 Consulting LLM...")
        analysis = call_llm(
            prompt="Analyze the provided macro data and generate a Trend-Eye report. Follow the schema strictly.",
            input_data=llm_input,
            schema=TREND_EYE_SCHEMA
        )

        if not analysis:
            print("   ❌ LLM returned empty analysis.")
            return

        # 5. Save to DB
        self._save_trend_eye(period_label, period_type, analysis, data_bundle)
        print("   ✅ Trend-Eye Analysis Saved.")

    def _load_data_bundle(self, start, end):
        print("   📥 Loading Data...")
        
        # Preprocess Data (Aggregated Facts)
        # We fetch the specific period's summary if available, or raw daily if not
        # For simplicity, let's fetch daily stats for the period
        daily_stats = self._fetch_table("preprocess_daily", start, end, ["date", "zscore", "delta_z", "country"])
        
        # Market Prices (Key Assets)
        prices = self._fetch_table("ingest_prices", start, end, ["date", "ticker", "close"])
        
        # News Headlines (Sample)
        news = self._fetch_news_sample(start, end)
        
        return {
            "daily_stats_summary": daily_stats.describe().to_dict() if not daily_stats.empty else {},
            "key_prices": self._summarize_prices(prices),
            "news_headlines": news
        }

    def _fetch_table(self, table, start, end, columns):
        try:
            res = self.supabase.table(table)\
                .select(",".join(columns))\
                .gte("date", start)\
                .lte("date", end)\
                .execute()
            return pd.DataFrame(res.data) if res.data else pd.DataFrame()
        except Exception as e:
            print(f"   ⚠️ Error fetching {table}: {e}")
            return pd.DataFrame()

    def _fetch_news_sample(self, start, end, limit=20):
        try:
            res = self.supabase.table("ingest_news")\
                .select("published_at, title, country")\
                .gte("published_at", start)\
                .lte("published_at", end)\
                .limit(limit)\
                .execute()
            return res.data if res.data else []
        except Exception as e:
            print(f"   ⚠️ Error fetching news: {e}")
            return []

    def _summarize_prices(self, df):
        if df.empty: return {}
        summary = {}
        for ticker in df['ticker'].unique():
            sub = df[df['ticker'] == ticker].sort_values('date')
            if sub.empty: continue
            start_price = sub.iloc[0]['close']
            end_price = sub.iloc[-1]['close']
            change = (end_price - start_price) / start_price
            summary[ticker] = {
                "start": start_price,
                "end": end_price,
                "change_pct": round(change * 100, 2)
            }
        return summary

    def _load_meta_rules(self):
        # Load the latest MetaRAG entry
        try:
            res = self.supabase.table("trend_validation_log")\
                .select("*")\
                .order("created_at", desc=True)\
                .limit(1)\
                .execute()
            
            if res.data:
                rag = res.data[0]
                return {
                    "signal_upweight": rag.get('signal_upweight'),
                    "signal_downweight": rag.get('signal_downweight'),
                    "pattern_promotions": rag.get('pattern_promotions'),
                    "consistent_errors": rag.get('consistent_errors'),
                    "recommended_rule_changes": rag.get('recommended_rule_changes')
                }
        except Exception as e:
            print(f"   ⚠️ Error loading MetaRAG: {e}")
        
        return {} # Default empty

    def _save_trend_eye(self, period, period_type, analysis, raw_data):
        record = {
            "period": period,
            "period_type": period_type,
            "macro_regime": analysis.get("macro_regime"),
            "macro_bias_score": analysis.get("macro_bias_score"),
            "trend_summary": analysis.get("trend_summary"),
            "market_drivers": json.dumps(analysis.get("market_drivers")),
            "country_strength": json.dumps(analysis.get("country_strength")),
            "asset_trend": json.dumps(analysis.get("asset_trend")),
            "risk_signals": json.dumps(analysis.get("risk_signals")),
            "opportunity_signals": json.dumps(analysis.get("opportunity_signals")),
            "recommended_positions": json.dumps(analysis.get("recommended_positions")),
            "confidence": analysis.get("confidence"),
            "raw_data_reference": json.dumps({"summary": "Data bundle used for analysis"}), # Simplified for now
            "created_at": "now()"
        }
        
        try:
            self.supabase.table("trend_eye_insights").insert(record).execute()
        except Exception as e:
            print(f"   ❌ Error saving Trend-Eye record: {e}")

if __name__ == "__main__":
    # Test Run
    engine = TrendEyeEngine()
    engine.generate_trend_eye("monthly", "2024-01-01", "2024-01-31", "2024-01")
