import os
import json
import urllib.request
import urllib.error
from dotenv import load_dotenv

load_dotenv()

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

def run_sql(query: str):
    url = f"{SUPABASE_URL}/rest/v1/rpc/run_sql"
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json"
    }
    
    data = json.dumps({"query": query}).encode('utf-8')
    req = urllib.request.Request(url, data=data, headers=headers, method='POST')
    
    try:
        with urllib.request.urlopen(req) as response:
            return json.loads(response.read().decode('utf-8'))
            
    except urllib.error.URLError as e:
        print(f"⚠️ [Warning] Connection failed to Supabase. Switching to MOCK MODE.")
        print(f"   (Error: {e})")
        
        # Mock Response Logic
        if "information_schema.columns" in query:
            # Mock Schema
            return [
                {"table_name": "ingest_news", "column_name": "id", "data_type": "int8"},
                {"table_name": "ingest_news", "column_name": "title", "data_type": "text"},
                {"table_name": "ingest_news", "column_name": "summary", "data_type": "text"},
                {"table_name": "ingest_news", "column_name": "published_at", "data_type": "timestamp"},
                {"table_name": "market_signals", "column_name": "ticker", "data_type": "text"},
                {"table_name": "market_signals", "column_name": "signal_score", "data_type": "float4"},
            ]
        else:
            # Mock Data Result
            return [
                {"title": "Fed Signals Rate Cut", "summary": "Jerome Powell hints at 25bps cut.", "signal_score": 0.9},
                {"title": "China Tech Rally", "summary": "Alibaba and Tencent surge on new stimulus.", "signal_score": 0.85},
                {"title": "Yen Weakens", "summary": "BOJ maintains dovish stance.", "signal_score": 0.7},
                {"title": "Samsung Electronics Earnings Shock", "summary": "Chip demand slows down.", "signal_score": 0.88}
            ]

    except Exception as e:
        print(f"❌ Error running SQL: {e}")
        raise
