-- Clean up garbage data for KR, JP, CN, GLOBAL before 2000
-- Run this in Supabase SQL Editor

DELETE FROM preprocess_daily 
WHERE country IN ('KR', 'JP', 'CN', 'GLOBAL') ㅁ
AND date < '2000-01-01';

-- Also clean up any reports if they were generated
DELETE FROM preprocess_weekly 
WHERE country IN ('KR', 'JP', 'CN', 'GLOBAL') 
AND start_date < '2000-01-01';

DELETE FROM preprocess_monthly 
WHERE country IN ('KR', 'JP', 'CN', 'GLOBAL') 
AND year < 2000;

DELETE FROM preprocess_annual 
WHERE country IN ('KR', 'JP', 'CN', 'GLOBAL') 
AND year < 2000;
