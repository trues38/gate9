import json
from config_db import get_supabase_client
from llm_utils import call_llm

# --- SCHEMA ---
META_RAG_SCHEMA = """
{
    "meta_period": "string (e.g., '2025-Q1')",
    "aggregate_score": "float (0.0 to 1.0)",
    "signal_upweight": ["string (Signals to trust more)"],
    "signal_downweight": ["string (Signals to trust less)"],
    "pattern_promotions": ["string (Patterns verified to be predictive)"],
    "pattern_demotions": ["string (Patterns found to be false alarms)"],
    "consistent_errors": ["string (Repeated mistakes to avoid)"],
    "recommended_rule_changes": ["string (New guidelines for the AI)"],
    "notes_for_next_cycle": ["string (Free text advice)"]
}
"""

class MetaRAGEngine:
    def __init__(self):
        self.supabase = get_supabase_client()

    def run_learning_cycle(self, meta_period_label):
        """
        Aggregates recent verifications and updates the MetaRAG knowledge base.
        """
        print(f"🧠 MetaRAG: Learning from recent verifications for {meta_period_label}...")

        # 1. Fetch Verified Insights
        # We want records that HAVE evaluation data
        verified_records = self._fetch_verified_records()
        if not verified_records:
            print("   ⚠️ No verified records found to learn from.")
            return

        print(f"   📚 Analyzing {len(verified_records)} verified cases...")

        # 2. Construct LLM Input
        # Extract the "Evaluation" part from each record
        evaluations = [r['evaluation_placeholder'] for r in verified_records if r.get('evaluation_placeholder')]
        
        llm_input = {
            "task": "META_LEARNING",
            "evaluations": evaluations
        }

        # 3. Call LLM
        print("   🧠 Synthesizing new knowledge...")
        meta_knowledge = call_llm(
            prompt="Analyze the verification results. Identify consistent errors, successful patterns, and update the rules.",
            input_data=llm_input,
            schema=META_RAG_SCHEMA
        )

        if not meta_knowledge:
            print("   ❌ LLM returned empty meta-knowledge.")
            return

        # 4. Save to DB (trend_validation_log)
        self._save_meta_knowledge(meta_period_label, meta_knowledge)
        print("   ✅ MetaRAG Updated. The system has evolved.")

    def _fetch_verified_records(self, limit=50):
        # Fetch records where evaluation_placeholder is not null/empty
        # Supabase filtering on JSONB existence is tricky, fetching recent 50 and filtering in python for now
        try:
            res = self.supabase.table("trend_eye_insights")\
                .select("*")\
                .order("created_at", desc=True)\
                .limit(limit)\
                .execute()
            
            # Filter for those with "verified": true inside the json
            verified = []
            for r in res.data:
                eval_data = r.get('evaluation_placeholder')
                if eval_data and isinstance(eval_data, dict) and eval_data.get('verified') is True:
                    verified.append(r)
            return verified
            
        except Exception as e:
            print(f"   ⚠️ Error fetching records: {e}")
            return []

    def _save_meta_knowledge(self, meta_period, data):
        record = {
            "meta_period": meta_period,
            "aggregate_score": data.get("aggregate_score"),
            "signal_upweight": json.dumps(data.get("signal_upweight")),
            "signal_downweight": json.dumps(data.get("signal_downweight")),
            "pattern_promotions": json.dumps(data.get("pattern_promotions")),
            "pattern_demotions": json.dumps(data.get("pattern_demotions")),
            "consistent_errors": json.dumps(data.get("consistent_errors")),
            "recommended_rule_changes": json.dumps(data.get("recommended_rule_changes")),
            "notes_for_next_cycle": json.dumps(data.get("notes_for_next_cycle"))
        }
        
        try:
            self.supabase.table("trend_validation_log").insert(record).execute()
        except Exception as e:
            print(f"   ❌ Error saving MetaRAG record: {e}")

if __name__ == "__main__":
    engine = MetaRAGEngine()
    # engine.run_learning_cycle("2025-Q1")
