-- G9 Macro Engine - Phase 2 & 3 Schema
-- Run this in Supabase SQL Editor

-- 1. Backtest Results (Raw Signals)
CREATE TABLE IF NOT EXISTS backtest_results (
    id BIGSERIAL PRIMARY KEY,
    date DATE NOT NULL,
    ticker TEXT NOT NULL,
    strategy_id TEXT NOT NULL,
    signal_type TEXT NOT NULL, -- LONG, SHORT
    signal_value FLOAT,        -- The Z-score or metric value
    fwd_return_1d FLOAT,
    fwd_return_5d FLOAT,
    fwd_return_20d FLOAT,
    is_valid_signal BOOLEAN DEFAULT TRUE,
    metadata JSONB,            -- Strategy params
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(date, ticker, strategy_id)
);

-- 2. Strategy Performance (Aggregated Stats)
CREATE TABLE IF NOT EXISTS strategy_performance (
    id BIGSERIAL PRIMARY KEY,
    strategy_id TEXT NOT NULL,
    ticker TEXT NOT NULL,
    start_date DATE,
    end_date DATE,
    total_signals INT,
    win_rate_1d FLOAT,
    win_rate_5d FLOAT,
    avg_return_1d FLOAT,
    avg_return_5d FLOAT,
    cagr FLOAT,
    sharpe_ratio FLOAT,
    max_drawdown FLOAT,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(strategy_id, ticker)
);

-- 3. Selected Strategies (For Report Engine)
CREATE TABLE IF NOT EXISTS preprocess_strategies (
    id BIGSERIAL PRIMARY KEY,
    strategy_id TEXT NOT NULL,
    category TEXT, -- PRIMITIVE, COMPOSITE, PATTERN
    description TEXT,
    performance_summary JSONB, -- Snapshot of performance
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(strategy_id)
);

-- Enable RLS
ALTER TABLE backtest_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE strategy_performance ENABLE ROW LEVEL SECURITY;
ALTER TABLE preprocess_strategies ENABLE ROW LEVEL SECURITY;

-- Policies
CREATE POLICY "Enable all access for service role" ON backtest_results FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON strategy_performance FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Enable all access for service role" ON preprocess_strategies FOR ALL USING (true) WITH CHECK (true);
