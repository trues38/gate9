from report_engine import ReportEngine
import argparse

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--start_year", type=int, default=1970)
    parser.add_argument("--end_year", type=int, default=2025)
    args = parser.parse_args()
    
    print(f"🏎️  Starting G9 Report Engine v2.0 ({args.start_year}-{args.end_year})...")
    engine = ReportEngine()
    engine.run_pipeline(start_year=args.start_year, end_year=args.end_year)
    print("🎉 Report Generation Complete!")

if __name__ == "__main__":
    main()
