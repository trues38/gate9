python3 preprocess_launcher.py --total_nodes 4 --node_id 2
