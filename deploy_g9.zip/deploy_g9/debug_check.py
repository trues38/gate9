import os
import sys
from preprocess_engine import DailyPreprocessor
from config_db import get_supabase_client

print("🔍 Debugging Deployment Package...")

# 1. Check Env
url = os.getenv("SUPABASE_URL")
if not url:
    print("❌ SUPABASE_URL not found in env!")
else:
    print(f"✅ SUPABASE_URL found: {url[:10]}...")

# 2. Run Processor for 2024-01-04 (US)
print("\n⚙️ Running DailyPreprocessor for 2024-01-04 (US)...")
processor = DailyPreprocessor()

# Fetch manually
headlines = processor._fetch_headlines("2024-01-04", "US")
print(f"   📰 Fetched Headlines Count: {len(headlines)}")

if len(headlines) == 0:
    print("   ⚠️ Warning: 0 headlines fetched. Check ingest_news table for 2024-01-04 US.")
else:
    print("   ✅ Headlines fetched successfully.")

# Save
success = processor.process("2024-01-04", "US")
print(f"   🏁 Process Result: {success}")

# Check DB
supabase = get_supabase_client()
res = supabase.table("preprocess_daily").select("*").eq("date", "2024-01-04").eq("country", "US").execute()
if res.data:
    row = res.data[0]
    print(f"   📊 DB Row Found: headline_count={row.get('headline_count')}")
else:
    print("   ❌ DB Row NOT Found!")
